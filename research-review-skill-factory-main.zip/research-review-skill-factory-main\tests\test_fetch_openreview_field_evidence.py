from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "fetch_openreview_field_evidence.py"
SPEC = importlib.util.spec_from_file_location("fetch_openreview_field_evidence", SCRIPT)
assert SPEC is not None
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def paper(year: int, reviewed: bool = True) -> dict[str, object]:
    return {
        "year": year,
        "status": "accepted",
        "title": "Graph Neural Networks",
        "abstract": "Graph neural network oversmoothing",
        "keywords": ["graph", "learning"],
        "primary_area": "representation learning",
        "venue": "ICLR",
        "decision": "Accept",
        "reviews": [{"kind": "Official_Review"}] if reviewed else [],
        "reviewer_comments": [],
        "meta_reviews": [],
        "author_responses": [{"kind": "Rebuttal"}],
    }


class FetchOpenReviewEvidenceTest(unittest.TestCase):
    def test_default_year_window_uses_current_and_two_previous(self) -> None:
        self.assertEqual(MODULE.default_year_window(2030), [2030, 2029, 2028])

    def test_summary_marks_sparse_below_twenty_reviewed_papers(self) -> None:
        papers = [paper(2030) for _ in range(19)]
        summary = MODULE.build_evidence_summary("graph neural network", [2030, 2029, 2028], papers, [], 20)
        self.assertFalse(summary["sufficient_openreview"])
        self.assertEqual(summary["evidence_mode"], "contrastive_required")
        self.assertEqual(summary["reviewed_papers"], 19)

    def test_summary_passes_at_twenty_reviewed_papers(self) -> None:
        papers = [paper(2030) for _ in range(20)]
        summary = MODULE.build_evidence_summary("graph neural network", [2030, 2029, 2028], papers, [], 20)
        self.assertTrue(summary["sufficient_openreview"])
        self.assertEqual(summary["evidence_mode"], "openreview")

    def test_multi_area_counts_are_independent(self) -> None:
        first = MODULE.build_evidence_summary("area one", [2030, 2029, 2028], [paper(2030) for _ in range(10)], [], 20)
        second = MODULE.build_evidence_summary("area two", [2030, 2029, 2028], [paper(2030) for _ in range(20)], [], 20)
        self.assertFalse(first["sufficient_openreview"])
        self.assertTrue(second["sufficient_openreview"])
        self.assertEqual(first["reviewed_papers"] + second["reviewed_papers"], 30)


if __name__ == "__main__":
    unittest.main()
