#!/usr/bin/env python3
"""Build validated anonymized contrastive taste profile from train and held-out pair reviews."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


FORBIDDEN_PATTERNS = [
    re.compile(r"https?://", re.IGNORECASE),
    re.compile(r"\bdoi\s*:", re.IGNORECASE),
    re.compile(r"\barxiv\b\s*[:/]?\s*\d", re.IGNORECASE),
    re.compile(r"\b[A-Za-z]:\\"),
    re.compile(r"/Users/|/home/", re.IGNORECASE),
    re.compile(r'"(?:url|local_path|title_or_name|author|authors)"\s*:', re.IGNORECASE),
]


def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object.")
    return data


def assert_no_forbidden_identity(payload: dict[str, Any]) -> None:
    text = json.dumps(payload, ensure_ascii=False)
    for pattern in FORBIDDEN_PATTERNS:
        if pattern.search(text):
            raise ValueError(f"Pair review bank contains forbidden identifying metadata matching {pattern.pattern!r}")


def concern_text(item: Any) -> str:
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, dict):
        for key in ["concern", "reviewer_concern", "axis", "summary"]:
            value = item.get(key)
            if value:
                return str(value).strip()
    return ""


def concern_detail(item: Any, key: str, fallback: str) -> str:
    if isinstance(item, dict) and item.get(key):
        return str(item[key]).strip()
    return fallback


def completed_reviews(bank: dict[str, Any], min_pairs_per_area: int, split_name: str) -> list[dict[str, Any]]:
    reviews = bank.get("pair_reviews", [])
    if not isinstance(reviews, list):
        raise ValueError(f"{split_name} pair review bank must contain a pair_reviews list.")
    incomplete = [review.get("pair_id", "unknown") for review in reviews if not review.get("completed")]
    if incomplete:
        raise ValueError(f"{split_name} pair review bank contains incomplete reviews: {', '.join(incomplete[:8])}")
    by_area: dict[str, int] = defaultdict(int)
    for review in reviews:
        by_area[str(review.get("area_slug", "unknown"))] += 1
    sparse = {area: count for area, count in by_area.items() if count < min_pairs_per_area}
    if sparse:
        details = ", ".join(f"{area}={count}" for area, count in sorted(sparse.items()))
        raise ValueError(f"Every area needs at least {min_pairs_per_area} completed {split_name} pair reviews; found {details}.")
    if not reviews:
        raise ValueError(f"{split_name} pair review bank has no completed reviews.")
    return reviews


def aggregate_concerns(reviews: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str], dict[str, Any]] = {}
    total_by_area: dict[str, int] = defaultdict(int)
    for review in reviews:
        total_by_area[str(review.get("area_slug", "unknown"))] += 1
    for review in reviews:
        area = str(review.get("area_slug", "unknown"))
        pair_id = str(review.get("pair_id", "unknown"))
        differences = review.get("pairwise_difference") or []
        fallback_basis = "; ".join(str(item) for item in differences[:3]) or "reported by completed pair review"
        for item in review.get("inferred_reviewer_concerns") or []:
            text = concern_text(item)
            if not text:
                continue
            key = (area, text.lower())
            entry = grouped.setdefault(
                key,
                {
                    "area_slug": area,
                    "concern": text,
                    "pair_ids": [],
                    "high_level_signal": [],
                    "general_level_gap": [],
                    "why_this_implies_reviewer_attention": [],
                    "counterexamples": [],
                    "total_pairs_in_area": total_by_area[area],
                },
            )
            entry["pair_ids"].append(pair_id)
            entry["high_level_signal"].append(concern_detail(item, "high_level_signal", fallback_basis))
            entry["general_level_gap"].append(concern_detail(item, "general_level_gap", fallback_basis))
            entry["why_this_implies_reviewer_attention"].append(
                concern_detail(item, "why", "repeated high/general contrast in completed pair review")
            )
            counterexample = concern_detail(item, "counterexample", "")
            if counterexample:
                entry["counterexamples"].append(counterexample)
    result = list(grouped.values())
    if not result:
        raise ValueError("No inferred_reviewer_concerns found in completed pair reviews.")
    result.sort(key=lambda item: (-len(item["pair_ids"]), item["area_slug"], item["concern"]))
    for item in result:
        coverage = len(set(item["pair_ids"])) / max(1, item["total_pairs_in_area"])
        item["pair_ids"] = sorted(set(item["pair_ids"]))
        item["coverage"] = round(coverage, 3)
        item["strength"] = strength_from_coverage(coverage)
        item["high_level_signal"] = sorted(set(item["high_level_signal"]))[:5]
        item["general_level_gap"] = sorted(set(item["general_level_gap"]))[:5]
        item["why_this_implies_reviewer_attention"] = sorted(set(item["why_this_implies_reviewer_attention"]))[:5]
        item["counterexamples"] = sorted(set(item["counterexamples"]))[:5] or ["not reported"]
    return result


def strength_from_coverage(coverage: float) -> str:
    if coverage >= 0.5:
        return "strong"
    if coverage >= 0.25:
        return "moderate"
    return "weak"


def downgrade(strength: str) -> str:
    return {"strong": "moderate", "moderate": "weak", "weak": "weak"}[strength]


def strengthen(strength: str) -> str:
    return {"strong": "strong", "moderate": "strong", "weak": "moderate"}[strength]


def area_counts(reviews: list[dict[str, Any]]) -> dict[str, int]:
    counts: dict[str, int] = defaultdict(int)
    for review in reviews:
        counts[str(review.get("area_slug", "unknown"))] += 1
    return dict(sorted(counts.items()))


def review_concern_keys(review: dict[str, Any]) -> set[tuple[str, str]]:
    area = str(review.get("area_slug", "unknown"))
    keys: set[tuple[str, str]] = set()
    for item in review.get("inferred_reviewer_concerns") or []:
        text = concern_text(item)
        if text:
            keys.add((area, text.lower()))
    return keys


def pair_success_summary(
    reviews: list[dict[str, Any]],
    reference_by_key: dict[tuple[str, str], dict[str, Any]],
    min_success_rate: float,
) -> tuple[dict[str, Any], bool]:
    by_area: dict[str, dict[str, Any]] = {}
    reference_keys = set(reference_by_key)
    for review in reviews:
        area = str(review.get("area_slug", "unknown"))
        pair_id = str(review.get("pair_id", "unknown"))
        area_summary = by_area.setdefault(
            area,
            {"total_pairs": 0, "successful_pairs": 0, "failed_pair_ids": []},
        )
        area_summary["total_pairs"] += 1
        matched = sorted(key[1] for key in review_concern_keys(review) & reference_keys)
        if matched:
            area_summary["successful_pairs"] += 1
        else:
            area_summary["failed_pair_ids"].append(pair_id)
    passed = True
    for area, area_summary in by_area.items():
        total = max(1, int(area_summary["total_pairs"]))
        rate = int(area_summary["successful_pairs"]) / total
        area_summary["success_rate"] = round(rate, 3)
        area_summary["min_success_rate"] = min_success_rate
        area_summary["passed"] = rate >= min_success_rate
        if not area_summary["passed"]:
            passed = False
    return dict(sorted(by_area.items())), passed


def concern_count_map(reviews: list[dict[str, Any]]) -> Counter[tuple[str, str]]:
    counts: Counter[tuple[str, str]] = Counter()
    for review in reviews:
        for key in review_concern_keys(review):
            counts[key] += 1
    return counts


def top_axis_keys(counts: Counter[tuple[str, str]], top_n: int = 8) -> set[tuple[str, str]]:
    return {key for key, _count in counts.most_common(top_n)}


def training_stop_diagnostics(
    train_reviews: list[dict[str, Any]],
    train_by_key: dict[tuple[str, str], dict[str, Any]],
    min_train_success_rate: float,
    batch_size: int,
    min_axis_stability: float,
    max_new_axes_last_batch: int,
) -> dict[str, Any]:
    train_success_by_area, train_success_passed = pair_success_summary(
        train_reviews,
        train_by_key,
        min_train_success_rate,
    )
    cumulative_counts: Counter[tuple[str, str]] = Counter()
    seen_axes: set[tuple[str, str]] = set()
    previous_top: set[tuple[str, str]] = set()
    batches: list[dict[str, Any]] = []
    for batch_index, start in enumerate(range(0, len(train_reviews), batch_size), 1):
        batch = train_reviews[start : start + batch_size]
        batch_counts = concern_count_map(batch)
        batch_axes = set(batch_counts)
        new_axes = batch_axes - seen_axes
        cumulative_counts.update(batch_counts)
        seen_axes.update(batch_axes)
        current_top = top_axis_keys(cumulative_counts)
        if previous_top:
            union = current_top | previous_top
            jaccard = len(current_top & previous_top) / max(1, len(union))
        else:
            jaccard = 1.0
        batches.append(
            {
                "batch_index": batch_index,
                "pair_count": len(batch),
                "new_axis_count": len(new_axes),
                "top_axis_jaccard_with_previous": round(jaccard, 3),
            }
        )
        previous_top = current_top
    latest = batches[-1] if batches else {"new_axis_count": 0, "top_axis_jaccard_with_previous": 1.0}
    axis_stability_passed = latest["top_axis_jaccard_with_previous"] >= min_axis_stability
    new_axis_passed = latest["new_axis_count"] <= max_new_axes_last_batch
    stop_passed = train_success_passed and axis_stability_passed and new_axis_passed
    return {
        "min_train_success_rate": min_train_success_rate,
        "train_success_by_area": train_success_by_area,
        "train_success_passed": train_success_passed,
        "batch_size": batch_size,
        "min_axis_stability": min_axis_stability,
        "max_new_axes_last_batch": max_new_axes_last_batch,
        "latest_new_axis_count": latest["new_axis_count"],
        "latest_top_axis_jaccard": latest["top_axis_jaccard_with_previous"],
        "axis_stability_passed": axis_stability_passed,
        "new_axis_saturation_passed": new_axis_passed,
        "training_stop_passed": stop_passed,
        "batches": batches,
    }


def public_validation_success(success_by_area: dict[str, Any]) -> dict[str, Any]:
    public: dict[str, Any] = {}
    for area, summary in success_by_area.items():
        public[area] = {
            "total_pairs": summary["total_pairs"],
            "successful_pairs": summary["successful_pairs"],
            "success_rate": summary["success_rate"],
            "min_success_rate": summary["min_success_rate"],
            "passed": summary["passed"],
        }
    return public


def public_training_diagnostics(diagnostics: dict[str, Any]) -> dict[str, Any]:
    public = {
        key: value
        for key, value in diagnostics.items()
        if key not in {"batches", "train_success_by_area"}
    }
    public["train_success_by_area"] = public_validation_success(diagnostics["train_success_by_area"])
    return public


def build_reports(
    train_bank: dict[str, Any],
    validation_bank: dict[str, Any],
    min_train_pairs_per_area: int,
    min_validation_pairs_per_area: int,
    evidence_mode: str,
    min_validation_success_rate: float = 0.9,
    min_train_success_rate: float = 0.95,
    training_batch_size: int = 200,
    min_axis_stability: float = 0.85,
    max_new_axes_last_batch: int = 1,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    assert_no_forbidden_identity(train_bank)
    assert_no_forbidden_identity(validation_bank)
    train_reviews = completed_reviews(train_bank, min_train_pairs_per_area, "training")
    validation_reviews = completed_reviews(validation_bank, min_validation_pairs_per_area, "validation")
    train_concerns = aggregate_concerns(train_reviews)
    validation_concerns = aggregate_concerns(validation_reviews)
    validation_by_key = {(item["area_slug"], item["concern"].lower()): item for item in validation_concerns}
    train_by_key = {(item["area_slug"], item["concern"].lower()): item for item in train_concerns}
    train_diagnostics = training_stop_diagnostics(
        train_reviews,
        train_by_key,
        min_train_success_rate,
        training_batch_size,
        min_axis_stability,
        max_new_axes_last_batch,
    )
    if not train_diagnostics["training_stop_passed"]:
        raise ValueError(
            "Training stop criteria not met: "
            f"train_success_passed={train_diagnostics['train_success_passed']}, "
            f"axis_stability_passed={train_diagnostics['axis_stability_passed']}, "
            f"new_axis_saturation_passed={train_diagnostics['new_axis_saturation_passed']}."
        )
    success_by_area, success_passed = pair_success_summary(
        validation_reviews,
        train_by_key,
        min_validation_success_rate,
    )
    if not success_passed:
        details = ", ".join(
            f"{area}={summary['success_rate']}"
            for area, summary in success_by_area.items()
            if not summary["passed"]
        )
        raise ValueError(
            f"Held-out validation success rate is below {min_validation_success_rate:.2f}; found {details}."
        )
    generated_at = dt.datetime.now(dt.timezone.utc).isoformat()

    final_axes: list[dict[str, Any]] = []
    unsupported_axes: list[dict[str, Any]] = []
    supported_axes: list[dict[str, Any]] = []
    for item in train_concerns:
        key = (item["area_slug"], item["concern"].lower())
        validation = validation_by_key.get(key)
        validation_coverage = validation["coverage"] if validation else 0.0
        strength = item["strength"]
        action = "kept"
        if validation is None:
            strength = downgrade(strength)
            action = "weakened_no_validation_support"
            unsupported_axes.append({"area_slug": item["area_slug"], "concern": item["concern"], "reason": action})
        else:
            supported_axes.append({"area_slug": item["area_slug"], "concern": item["concern"], "validation_coverage": validation_coverage})
            if validation_coverage < 0.25 or validation_coverage < item["coverage"] * 0.5:
                strength = downgrade(strength)
                action = "weakened_low_validation_support"
                unsupported_axes.append(
                    {
                        "area_slug": item["area_slug"],
                        "concern": item["concern"],
                        "reason": action,
                        "training_coverage": item["coverage"],
                        "validation_coverage": validation_coverage,
                    }
                )
            elif validation_coverage >= 0.5 and validation_coverage > item["coverage"] * 1.25:
                strength = strengthen(strength)
                action = "strengthened_by_validation_support"
        final_axes.append(
            {
                "area_slug": item["area_slug"],
                "summary": item["concern"],
                "training_coverage": item["coverage"],
                "validation_coverage": validation_coverage,
                "strength": strength,
                "calibration_action": action,
                "reviewer_concern": item["concern"],
                "what_future_papers_must_show": "Address this concern with explicit evidence in the target paper.",
                "rebuttal_revision_use": "Use text clarification only when paper evidence already exists; otherwise add experiment, analysis, or scope control.",
                "training_pair_ids": item["pair_ids"],
                "validation_pair_ids": validation["pair_ids"] if validation else [],
            }
        )

    missed_concerns: list[dict[str, Any]] = []
    for key, validation in validation_by_key.items():
        if key in train_by_key:
            continue
        missed_concerns.append(
            {
                "area_slug": validation["area_slug"],
                "concern": validation["concern"],
                "validation_coverage": validation["coverage"],
                "validation_pair_ids": validation["pair_ids"],
                "action": "reported_external_only_validation_not_used_for_training" if validation["coverage"] >= 0.25 else "reported_not_added_low_validation_coverage",
            }
        )

    final_axes.sort(key=lambda axis: ({"strong": 0, "moderate": 1, "weak": 2}[axis["strength"]], -axis["validation_coverage"], -axis["training_coverage"], axis["summary"]))
    profile = {
        "generated_at_utc": generated_at,
        "evidence_mode": evidence_mode,
        "privacy": "anonymous validated taste profile; detailed reviews and validation reports remain external",
        "train_pair_counts": area_counts(train_reviews),
        "training_stop_diagnostics": public_training_diagnostics(train_diagnostics),
        "validation_pair_counts": area_counts(validation_reviews),
        "validation_success_by_area": success_by_area,
        "taste_axes": final_axes,
    }
    rationale = {
        "generated_at_utc": generated_at,
        "privacy": "anonymous training rationale; not intended for child skill packaging",
        "train_pair_counts": area_counts(train_reviews),
        "training_stop_diagnostics": train_diagnostics,
        "concerns": train_concerns,
    }
    validation_report = {
        "generated_at_utc": generated_at,
        "privacy": "anonymous held-out validation report; not intended for child skill packaging",
        "validation_pair_counts": area_counts(validation_reviews),
        "min_validation_success_rate": min_validation_success_rate,
        "validation_success_by_area": success_by_area,
        "validation_success_passed": success_passed,
        "supported_axes": supported_axes,
        "unsupported_axes": unsupported_axes,
        "missed_concerns": missed_concerns,
        "final_axis_count": len(final_axes),
    }
    return profile, rationale, validation_report


def write_outputs(output: Path, profile: dict[str, Any], rationale: dict[str, Any], validation_report: dict[str, Any]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "contrastive_taste_profile.json").write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "contrastive_inference_rationale_report.json").write_text(json.dumps(rationale, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "validation_report.json").write_text(json.dumps(validation_report, ensure_ascii=False, indent=2), encoding="utf-8")

    profile_lines = [
        "# Contrastive Reviewer Taste Profile",
        "",
        f"- Evidence mode: `{profile['evidence_mode']}`",
        "- Privacy: anonymous IDs only",
        "- Calibration: held-out validation applied; detailed review banks and validation report are external artifacts",
        "",
        "## Training Stop Criteria",
        "",
        f"- Training diagnostics: `{profile['training_stop_diagnostics']}`",
        "",
        "## Pair Counts",
        "",
        f"- Training: `{profile['train_pair_counts']}`",
        f"- Validation: `{profile['validation_pair_counts']}`",
        f"- Validation success: `{public_validation_success(profile['validation_success_by_area'])}`",
        "",
        "## Taste Axes",
        "",
    ]
    for index, axis in enumerate(profile["taste_axes"], 1):
        profile_lines.extend(
            [
                f"### Axis {index}: {axis['summary']}",
                "",
                f"- Area: `{axis['area_slug']}`",
                f"- Strength: `{axis['strength']}`",
                f"- Training coverage: `{axis['training_coverage']}`",
                f"- Validation coverage: `{axis['validation_coverage']}`",
                f"- Calibration action: `{axis['calibration_action']}`",
                f"- Reviewer concern: {axis['reviewer_concern']}",
                f"- Future-paper requirement: {axis['what_future_papers_must_show']}",
                f"- Rebuttal/revision use: {axis['rebuttal_revision_use']}",
                "",
            ]
        )
    (output / "contrastive_taste_profile.md").write_text("\n".join(profile_lines), encoding="utf-8")

    rationale_lines = ["# Contrastive Inference Rationale Report", "", "- Privacy: anonymous IDs only", ""]
    for index, concern in enumerate(rationale["concerns"], 1):
        rationale_lines.extend(
            [
                f"## Rationale {index}: {concern['concern']}",
                "",
                f"- Area: `{concern['area_slug']}`",
                f"- Strength: `{concern['strength']}`",
                f"- Coverage: `{concern['coverage']}`",
                f"- Pair IDs: `{', '.join(concern['pair_ids'][:30])}`",
                "- High-level signal:",
            ]
        )
        rationale_lines.extend(f"  - {item}" for item in concern["high_level_signal"])
        rationale_lines.append("- General-level gap:")
        rationale_lines.extend(f"  - {item}" for item in concern["general_level_gap"])
        rationale_lines.append("- Why this implies reviewer attention:")
        rationale_lines.extend(f"  - {item}" for item in concern["why_this_implies_reviewer_attention"])
        rationale_lines.append("")
    (output / "contrastive_inference_rationale_report.md").write_text("\n".join(rationale_lines), encoding="utf-8")

    validation_lines = [
        "# Held-Out Validation Report",
        "",
        "- Privacy: anonymous IDs only",
        "",
        f"- Minimum validation success rate: `{validation_report['min_validation_success_rate']}`",
        f"- Validation success passed: `{validation_report['validation_success_passed']}`",
        "",
        "## Validation Success By Area",
        "",
    ]
    for area, summary in validation_report["validation_success_by_area"].items():
        validation_lines.append(
            f"- `{area}` success_rate={summary['success_rate']} successful_pairs={summary['successful_pairs']}/{summary['total_pairs']}"
        )
    validation_lines.extend(
        [
            "",
        "## Supported Axes",
        "",
        ]
    )
    validation_lines.extend(f"- `{item['area_slug']}` {item['concern']} validation_coverage={item['validation_coverage']}" for item in validation_report["supported_axes"])
    validation_lines.extend(["", "## Unsupported Or Downgraded Axes", ""])
    validation_lines.extend(f"- `{item['area_slug']}` {item['concern']}: {item['reason']}" for item in validation_report["unsupported_axes"])
    validation_lines.extend(["", "## Missed Concerns", ""])
    validation_lines.extend(f"- `{item['area_slug']}` {item['concern']}: {item['action']}" for item in validation_report["missed_concerns"])
    (output / "validation_report.md").write_text("\n".join(validation_lines), encoding="utf-8")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair-review-bank", required=True, help="Path to completed training pair_review_bank.json.")
    parser.add_argument("--validation-review-bank", required=True, help="Path to completed validation_pair_review_bank.json.")
    parser.add_argument("--output-dir", required=True, help="Directory for profile and external reports.")
    parser.add_argument("--min-train-pairs-per-area", type=int, default=20)
    parser.add_argument("--min-validation-pairs-per-area", type=int, default=21)
    parser.add_argument("--min-validation-success-rate", type=float, default=0.9)
    parser.add_argument("--min-train-success-rate", type=float, default=0.95)
    parser.add_argument("--training-batch-size", type=int, default=200)
    parser.add_argument("--min-axis-stability", type=float, default=0.85)
    parser.add_argument("--max-new-axes-last-batch", type=int, default=1)
    parser.add_argument("--evidence-mode", default="contrastive", choices=["contrastive", "hybrid"])
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    profile, rationale, validation_report = build_reports(
        read_json(Path(args.pair_review_bank)),
        read_json(Path(args.validation_review_bank)),
        args.min_train_pairs_per_area,
        args.min_validation_pairs_per_area,
        args.evidence_mode,
        args.min_validation_success_rate,
        args.min_train_success_rate,
        args.training_batch_size,
        args.min_axis_stability,
        args.max_new_axes_last_batch,
    )
    write_outputs(Path(args.output_dir), profile, rationale, validation_report)
    print(Path(args.output_dir).resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(__import__("sys").argv[1:]))
