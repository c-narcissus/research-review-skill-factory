# Research Review Skill Factory

## 中文发布页信息

`research-review-skill-factory` 是一个用于生成领域级审稿 skill 的元 skill。它会优先检索 OpenReview 公开审稿证据，并在证据不足时切换到“高水平样本 vs 一般水平样本”的对比学习流程，归纳审稿人的品味和判断标准。

## 核心能力

- 为一个或多个研究领域分别建立领域画像。
- 自动使用运行时当前年份及前两年作为默认 OpenReview 检索窗口。
- 对每个领域独立检查最近三年是否至少有 20 篇带公开审稿意见的相关论文。
- 多领域请求不能合并不同领域的论文数来凑满门槛。
- OpenReview 证据充足时，生成领域 review-response bank。
- OpenReview 证据稀疏时，读取或下载用户提供的高水平/一般水平样本来源，每个领域至少做 20 次匿名同领域配对评审，生成 contrastive reviewer taste profile 和独立依据报告。
- 生成的子 skill 不保留参与对比学习论文的标题、作者、文件名、URL、路径、DOI、arXiv ID 或原始身份映射。
- 生成可复用的子审稿 skill，用于后续论文审稿、rebuttal 规划和修改建议。

## 推荐使用场景

- 为新兴研究方向构建专属审稿 skill。
- 为多个相近但独立的研究子领域分别建立审稿标准。
- 当 OpenReview 公开审稿意见不足时，用高水平论文和一般水平论文的对比来捕获 reviewer taste。

## 许可证

MIT-0
