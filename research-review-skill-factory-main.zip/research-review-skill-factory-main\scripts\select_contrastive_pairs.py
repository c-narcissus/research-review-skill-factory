#!/usr/bin/env python3
"""Select anonymous train/validation contrastive pairs with document-level holdout."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import random
from pathlib import Path
from typing import Any


def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return data


def eligible_samples(manifest: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        sample
        for sample in manifest.get("samples", [])
        if sample.get("selection_status") == "eligible" and sample.get("level") in {"high_level", "general_level"}
    ]


def document_key(sample: dict[str, Any], private_samples: dict[str, Any] | None) -> str:
    if private_samples:
        private = private_samples.get(sample["sample_id"], {})
        if private.get("document_key"):
            return str(private["document_key"])
    return str(sample["sample_id"])


def candidate_pairs(
    high: list[dict[str, Any]],
    general: list[dict[str, Any]],
    private_samples: dict[str, Any] | None,
) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for high_sample in high:
        for general_sample in general:
            if document_key(high_sample, private_samples) != document_key(general_sample, private_samples):
                pairs.append((high_sample["sample_id"], general_sample["sample_id"]))
    return pairs


def choose_validation_counts(
    high_count: int,
    general_count: int,
    validation_pairs: int,
    required_train_pairs: int,
) -> tuple[int, int]:
    preferred_high = min(validation_pairs, high_count)
    preferred_general = min(validation_pairs, general_count)
    if preferred_high * preferred_general >= validation_pairs and (high_count - preferred_high) * (general_count - preferred_general) >= required_train_pairs:
        return preferred_high, preferred_general

    best: tuple[int, int] | None = None
    for high_holdout in range(1, high_count + 1):
        for general_holdout in range(1, general_count + 1):
            if high_holdout * general_holdout < validation_pairs:
                continue
            if (high_count - high_holdout) * (general_count - general_holdout) < required_train_pairs:
                continue
            candidate = (high_holdout, general_holdout)
            if best is None or sum(candidate) < sum(best):
                best = candidate
    if best is None:
        raise ValueError(
            f"Cannot create {validation_pairs} held-out validation pairs and {required_train_pairs} train pairs "
            f"from {high_count} high-level and {general_count} general-level samples."
        )
    return best


def resolve_validation_pairs(
    candidate_count: int,
    max_pairs: int,
    min_train_pairs: int,
    requested_validation_pairs: int | None,
    min_validation_pairs: int,
    validation_fraction: float,
) -> tuple[int, int]:
    target_total_pairs = min(candidate_count, max_pairs)
    requested = requested_validation_pairs or 0
    validation_pairs = max(
        requested,
        min_validation_pairs,
        math.ceil(target_total_pairs * validation_fraction),
    )
    if validation_pairs + min_train_pairs > target_total_pairs:
        raise ValueError(
            f"Need at least {min_train_pairs} train pairs and {validation_pairs} validation pairs, "
            f"but only {target_total_pairs} total pairs are selectable under the max-pair policy."
        )
    return validation_pairs, target_total_pairs


def select_pairs(
    manifest: dict[str, Any],
    seed: int,
    private_map: dict[str, Any] | None = None,
    min_train_pairs: int = 20,
    validation_pairs: int | None = None,
    min_validation_pairs: int = 21,
    validation_fraction: float = 0.1,
    max_pairs: int = 2000,
) -> dict[str, Any]:
    if not 0 < validation_fraction < 1:
        raise ValueError("--validation-fraction must be greater than 0 and less than 1")
    if min_validation_pairs <= 20:
        raise ValueError("--min-validation-pairs must be greater than 20")
    requested_validation_pairs = validation_pairs
    minimum_validation_floor = max(min_validation_pairs, requested_validation_pairs or 0)
    if max_pairs < min_train_pairs + minimum_validation_floor:
        raise ValueError("--max-pairs must be at least min_train_pairs + the validation-pair floor")

    rng = random.Random(seed)
    private_samples = private_map.get("samples", {}) if private_map else None
    samples = eligible_samples(manifest)
    areas = sorted({sample["area_slug"] for sample in samples})
    training_pairs: list[dict[str, Any]] = []
    heldout_pairs: list[dict[str, Any]] = []
    summaries: dict[str, Any] = {}

    for area in areas:
        high = [sample for sample in samples if sample["area_slug"] == area and sample["level"] == "high_level"]
        general = [sample for sample in samples if sample["area_slug"] == area and sample["level"] == "general_level"]
        all_candidates = candidate_pairs(high, general, private_samples)
        effective_validation_pairs, target_total_pairs = resolve_validation_pairs(
            len(all_candidates),
            max_pairs,
            min_train_pairs,
            requested_validation_pairs,
            min_validation_pairs,
            validation_fraction,
        )
        required_training_pairs = target_total_pairs - effective_validation_pairs
        if len(all_candidates) < min_train_pairs + effective_validation_pairs:
            raise ValueError(
                f"Area '{area}' has only {len(all_candidates)} unique high/general pairs; "
                f"{min_train_pairs + effective_validation_pairs} required for train+validation."
            )

        try:
            high_holdout_count, general_holdout_count = choose_validation_counts(
                len(high),
                len(general),
                effective_validation_pairs,
                required_training_pairs,
            )
        except ValueError:
            high_holdout_count, general_holdout_count = choose_validation_counts(
                len(high),
                len(general),
                effective_validation_pairs,
                min_train_pairs,
            )
        shuffled_high = high[:]
        shuffled_general = general[:]
        rng.shuffle(shuffled_high)
        rng.shuffle(shuffled_general)
        validation_high = shuffled_high[:high_holdout_count]
        validation_general = shuffled_general[:general_holdout_count]
        training_high = shuffled_high[high_holdout_count:]
        training_general = shuffled_general[general_holdout_count:]

        validation_candidates = candidate_pairs(validation_high, validation_general, private_samples)
        training_candidates = candidate_pairs(training_high, training_general, private_samples)
        if len(validation_candidates) < effective_validation_pairs:
            raise ValueError(f"Area '{area}' has only {len(validation_candidates)} held-out validation pairs.")
        if len(training_candidates) < min_train_pairs:
            raise ValueError(f"Area '{area}' has only {len(training_candidates)} training pairs.")

        rng.shuffle(validation_candidates)
        rng.shuffle(training_candidates)
        validation_chosen = validation_candidates[:effective_validation_pairs]
        train_target = min(target_total_pairs - effective_validation_pairs, len(training_candidates))
        if train_target < min_train_pairs:
            raise ValueError(f"Area '{area}' can select only {train_target} training pairs; {min_train_pairs} required.")
        training_chosen = training_candidates[:train_target]

        summaries[area] = {
            "high_level_samples": len(high),
            "general_level_samples": len(general),
            "unique_candidate_pairs": len(all_candidates),
            "heldout_high_samples": high_holdout_count,
            "heldout_general_samples": general_holdout_count,
            "training_candidate_pairs": len(training_candidates),
            "validation_candidate_pairs": len(validation_candidates),
            "selected_training_pairs": len(training_chosen),
            "selected_validation_pairs": len(validation_chosen),
            "selected_total_pairs": len(training_chosen) + len(validation_chosen),
            "target_total_pairs": target_total_pairs,
            "validation_fraction": validation_fraction,
            "min_validation_pairs": min_validation_pairs,
            "requested_validation_pairs": requested_validation_pairs,
            "max_pairs": max_pairs,
        }
        for index, (high_id, general_id) in enumerate(training_chosen, 1):
            training_pairs.append(
                {
                    "pair_id": f"{area}:train_pair_{index:03d}",
                    "split": "train",
                    "area_slug": area,
                    "high_sample_id": high_id,
                    "general_sample_id": general_id,
                }
            )
        for index, (high_id, general_id) in enumerate(validation_chosen, 1):
            heldout_pairs.append(
                {
                    "pair_id": f"{area}:validation_pair_{index:03d}",
                    "split": "validation",
                    "area_slug": area,
                    "high_sample_id": high_id,
                    "general_sample_id": general_id,
                }
            )

    return {
        "generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "random_seed": seed,
        "min_train_pairs": min_train_pairs,
        "requested_validation_pairs_per_area": requested_validation_pairs,
        "min_validation_pairs_per_area": min_validation_pairs,
        "validation_fraction": validation_fraction,
        "validation_policy": "max(requested_validation_pairs, min_validation_pairs, ceil(target_total_pairs * validation_fraction))",
        "max_pairs_per_area": max_pairs,
        "privacy": "anonymous pair plan; validation sample IDs are document-level held out from training",
        "area_summaries": summaries,
        "training_pairs": training_pairs,
        "validation_pairs": heldout_pairs,
        "pairs": training_pairs + heldout_pairs,
    }


def write_outputs(output: Path, plan: dict[str, Any]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "contrastive_pair_plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "# Contrastive Pair Plan",
        "",
        f"- Random seed: `{plan['random_seed']}`",
        f"- Minimum train pairs per area: `{plan['min_train_pairs']}`",
        f"- Minimum validation pairs per area: `{plan['min_validation_pairs_per_area']}`",
        f"- Validation fraction: `{plan['validation_fraction']}`",
        f"- Validation policy: `{plan['validation_policy']}`",
        f"- Maximum total pairs per area: `{plan['max_pairs_per_area']}`",
        "- Privacy: anonymous IDs only; validation documents are held out from training",
        "",
    ]
    for area, summary in plan["area_summaries"].items():
        lines.extend(
            [
                f"## Area `{area}`",
                "",
                f"- High-level samples: `{summary['high_level_samples']}`",
                f"- General-level samples: `{summary['general_level_samples']}`",
                f"- Unique candidate pairs: `{summary['unique_candidate_pairs']}`",
                f"- Target total pairs: `{summary['target_total_pairs']}`",
                f"- Selected training pairs: `{summary['selected_training_pairs']}`",
                f"- Selected validation pairs: `{summary['selected_validation_pairs']}`",
                f"- Selected total pairs: `{summary['selected_total_pairs']}`",
                "",
                "### Training Pairs",
                "",
            ]
        )
        for pair in [item for item in plan["training_pairs"] if item["area_slug"] == area]:
            lines.append(f"- `{pair['pair_id']}`: `{pair['high_sample_id']}` vs `{pair['general_sample_id']}`")
        lines.extend(["", "### Held-Out Validation Pairs", ""])
        for pair in [item for item in plan["validation_pairs"] if item["area_slug"] == area]:
            lines.append(f"- `{pair['pair_id']}`: `{pair['high_sample_id']}` vs `{pair['general_sample_id']}`")
        lines.append("")
    (output / "contrastive_pair_plan.md").write_text("\n".join(lines), encoding="utf-8")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True, help="Path to sample_source_manifest.json.")
    parser.add_argument("--output", required=True, help="Output directory.")
    parser.add_argument("--private-source-map", help="Optional private_source_map.json to avoid pairing identical source documents.")
    parser.add_argument("--min-train-pairs", type=int, default=20)
    parser.add_argument("--validation-pairs", type=int, help="Optional requested validation pair floor per area.")
    parser.add_argument("--min-validation-pairs", type=int, default=21, help="Minimum validation pairs per area; must be greater than 20.")
    parser.add_argument("--validation-fraction", type=float, default=0.1, help="Minimum validation fraction of selected total pairs.")
    parser.add_argument("--max-pairs", type=int, default=2000)
    parser.add_argument("--seed", type=int)
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    manifest = read_json(Path(args.manifest))
    private_map = read_json(Path(args.private_source_map)) if args.private_source_map else None
    seed = args.seed if args.seed is not None else random.SystemRandom().randint(1, 2_147_483_647)
    plan = select_pairs(
        manifest,
        seed=seed,
        private_map=private_map,
        min_train_pairs=args.min_train_pairs,
        validation_pairs=args.validation_pairs,
        min_validation_pairs=args.min_validation_pairs,
        validation_fraction=args.validation_fraction,
        max_pairs=args.max_pairs,
    )
    write_outputs(Path(args.output), plan)
    print(
        f"Wrote {len(plan['training_pairs'])} training and {len(plan['validation_pairs'])} validation pairs "
        f"to {Path(args.output).resolve()}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(__import__("sys").argv[1:]))
