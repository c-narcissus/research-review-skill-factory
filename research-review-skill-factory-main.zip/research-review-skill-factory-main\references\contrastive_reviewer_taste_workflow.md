# Contrastive Reviewer Taste Workflow

Use this workflow when an area has sparse OpenReview evidence or when the user asks to compare high-level and general-level paper sets.

## Goal

Infer reviewer taste from contrasts between strong and ordinary samples. The result is not a ranking of papers; it is a reusable profile of what reviewers in the area appear to reward, tolerate, or penalize.

## Procedure

1. Collect or read sample sources using `contrastive_sample_source_schema.md`.
2. Build a public anonymized `sample_source_manifest.md/json` and a private, unbundled `private_source_map.json`.
3. Choose one contrastive module:
   - Default: read `contrastive_pair_review_workflow.md` for high-throughput pair selection, training, and validation.
   - Strict curated mode: read `deep_read_matched_contrastive_module.md` when the user asks to deeply read selected papers, match each high-level paper to a related general-level paper, and synthesize a detailed taste profile from one-to-one comparisons.
4. For the default high-throughput module, create up to 2000 same-area high/general pairs, with at least 20 training pairs and a document-level held-out validation split that is larger than 20 pairs and at least 10% of selected pairs.
5. Blind-review each training paper using `paper_review_rubric_for_contrastive.md` without exposing high/general labels.
6. Reveal labels only after blind single-paper reviews, then compare each pair.
7. Iterate on training data until train coverage is at least 95%, the latest 200-pair batch adds no more than one meaningful new axis, and top-axis stability is at least 0.85.
8. Build a frozen candidate taste profile from training pair reviews.
9. Only then deep-read held-out validation pairs and test whether the candidate taste axes explain those differences.
10. Require held-out validation success rate >= 90% per area. A validation pair succeeds when at least one inferred validation concern is covered by the training-derived taste axes.
11. Use final validation once to pass/fail and optionally strengthen or weaken existing axes; keep validation-only missed concerns external.
12. Write external `contrastive_inference_rationale_report.md/json` and `validation_report.md/json`.
13. Write `contrastive_taste_profile.md` as the concise child-skill-facing, validation-calibrated summary.

For the deep-read matched module, use the artifact contract in `deep_read_matched_contrastive_module.md`: deep-read reports, matched pair plans, and pair analyses stay external; only the final aggregate taste profile enters the child skill.

Taste profile axes normally include:

- problem importance and positioning;
- novelty threshold and A+B incrementality;
- mechanism or theory support;
- experimental design and baseline strength;
- ablation and causal attribution;
- dataset, metric, and setting credibility;
- reproducibility and implementation detail;
- clarity, scope control, and claim discipline.

The taste profile must be grounded in the completed pair review bank and rationale report. Do not infer reviewer taste directly from filenames, venues, labels, or source folders.

## Taste Profile Format

```markdown
# Contrastive Reviewer Taste Profile

## Evidence Mode

contrastive

## Sample Summary

- High-level samples: <count>
- General-level samples: <count>
- Limitations: <coverage limits>
- Pair reviews per area: at least 20
- Training stop: train coverage >= 95%, latest-batch new axes <= 1, top-axis stability >= 0.85
- Calibration: held-out validation applied; detailed reports are external artifacts

## Taste Axes

### <axis name>

- Summary:
- Evidence coverage:
- Reviewer concern:
- What future papers must show:
- Rebuttal/revision use:
- Rationale pointer:
  - Pair IDs:
  - Rationale report section:
```

## Privacy

Generated child skill references must contain only final anonymous taste axes. Do not include pair review banks, rationale reports, validation reports, paper titles, author names, raw filenames, URLs, paths, DOI strings, arXiv IDs, or other identifying metadata.
