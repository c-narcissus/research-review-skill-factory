# Evidence Sufficiency And Fallback

Use this gate after the OpenReview retrieval pass and before creating the child skill.

## Default Window

- Determine `current_year` at runtime.
- Use exactly three years by default: `current_year`, `current_year - 1`, and `current_year - 2`.
- If one year is unavailable, record it as a retrieval limitation. Do not add older years unless the user asks.

## Per-Area Gate

For each requested area, compute:

- `relevant_papers`: relevant OpenReview submissions matched by the area queries;
- `reviewed_papers`: relevant papers with at least one public review note;
- `public_review_notes`: official reviews plus equivalent public reviewer notes;
- `accepted_author_responses`: retained author responses from accepted papers;
- `years_requested` and `years_with_matches`;
- `query_terms_matched` and `query_terms_missing`.

An area passes only if:

```text
reviewed_papers >= 20
```

Do not pool papers across areas. If the user asks for three areas and only two pass, only those two may use the OpenReview-grounded path.

## Fallback Decision

- `openreview`: the area passes the 20-reviewed-paper gate.
- `contrastive`: the area fails the gate and must use high-level vs general-level samples.
- `hybrid`: the user explicitly asks to combine a sufficient OpenReview bank with contrastive samples.

When an area fails, say which area failed, report the observed count, and request or read high-level and general-level sample sources using `contrastive_sample_source_schema.md`.
