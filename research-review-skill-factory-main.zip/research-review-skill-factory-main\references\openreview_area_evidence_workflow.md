# OpenReview Area Evidence Workflow

Use this workflow to create a compact review-response bank for a research area or problem family.

## Year Selection

Use the runtime current year and two previous years by default:

```text
[current_year, current_year - 1, current_year - 2]
```

If the current ICLR year is not public or cannot be fetched, record that limitation. Do not silently expand to a fourth year unless the user explicitly asks for a wider window.

Record:

- date checked;
- years used;
- queries used;
- retrieval limitations.

## Retrieval Command

```bash
python scripts/fetch_openreview_field_evidence.py --field "<area query>" --per-status 8 --min-reviewed-papers 20 --output "<evidence-dir>/<area-slug>"
```

For multiple independent areas:

```bash
python scripts/fetch_openreview_field_evidence.py --field "<area 1>" --field "<area 2>" --field "<area 3>" --output "<evidence-dir>"
```

For smoke tests:

```bash
python scripts/fetch_openreview_field_evidence.py --field "<area query>" --per-status 1 --max-scanned-per-status 80 --output "<evidence-dir>/<area-slug>"
```

The script writes `evidence_summary.json` and `field_evidence.json`. For multiple fields, each field receives its own subdirectory plus a combined `all_fields_evidence_summary.json`.

## Sufficiency Gate

Read `evidence_sufficiency_and_fallback.md` before deciding how to build the child skill.

- Each area must independently have at least 20 relevant papers with public review notes.
- A paper counts only if it has at least one `Official_Review` or equivalent public reviewer note.
- Do not combine counts across areas, subareas, or fallback fields.
- If an area has fewer than 20 reviewed papers in the three-year window, mark it `contrastive_required`.

## Evidence Rules

- Include reviewer concerns from accepted, rejected, withdrawn, and desk-rejected public submissions when available.
- Include author responses only from accepted papers by default.
- Keep a representative sample across subareas rather than overfitting to one keyword.
- Mark weak or analogical evidence explicitly.

## Bank Entry Format

Use this format in the generated child skill:

```markdown
## Category: <concern category>

- Trigger terms: <keywords>
- Reviewer precedent: <paraphrased concern pattern>
- Accepted-paper response pattern: <how successful authors handled it>
- Future-paper review use: <what reviewers should check in papers in this area>
- Rebuttal/revision use: <text-only, minor revision, new experiment, major revision, or insufficient>
- Evidence:
  - [ICLRYYYY status] Title. Note type. Forum: URL.
```

## Recommended Categories

- novelty and A+B positioning;
- theory-to-method alignment;
- mechanism evidence;
- baseline fairness and tuning;
- benchmark and metric validity;
- ablation completeness;
- reproducibility and implementation detail;
- hidden resources;
- communication/compute/privacy/safety/fairness;
- overclaim and scope control.
