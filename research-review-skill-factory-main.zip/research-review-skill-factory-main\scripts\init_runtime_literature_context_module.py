#!/usr/bin/env python3
"""Initialize a replaceable runtime literature context module plan."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


MODULE_NAME = "runtime_literature_context"
MODULE_VERSION = "1.0"
SAFE_SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,78}[a-z0-9])?$")

DEFAULT_SOURCES = [
    "OpenReview",
    "official venue proceedings",
    "journal publisher pages",
    "ACL Anthology",
    "DBLP",
    "Semantic Scholar",
    "OpenAlex",
    "Crossref",
    "Papers with Code",
    "preprint servers as supplemental fallback",
]

QUERY_LAYERS = [
    "target anchors",
    "same problem",
    "parent problem",
    "method lineage",
    "baseline and benchmark expectations",
    "recent top-conference/top-journal sweep",
    "contradictory or limitation-seeking pass",
]

REPLACEABLE_COMPONENTS = {
    "target_paper_parser": "extract target-paper anchors, claims, related works, methods, experiments, and references",
    "problem_lifter": "map the target contribution to parent problems and sibling subproblems",
    "query_planner": "create multi-hop scholarly search queries",
    "source_retriever": "query public scholarly sources or user-provided local corpora",
    "full_text_reader": "open or download accessible full text for critical related works and record section-level reading notes",
    "graph_builder": "build paper/problem/method/baseline/dataset/claim graph artifacts",
    "hybrid_ranker": "combine lexical, semantic, recency, citation, venue, and anchor-proximity signals",
    "evidence_summarizer": "summarize retrieved works with citations, full-text coverage status, and uncertainty",
    "review_context_mapper": "map retrieved works to novelty, baseline, evidence, assumption, and rebuttal implications",
    "privacy_and_source_filter": "prevent private paths, raw papers, API keys, and runtime traces from entering child skills",
}

RUNTIME_ARTIFACTS = [
    "runtime_literature_query_plan.md",
    "runtime_literature_query_plan.json",
    "retrieved_literature_metadata.json",
    "full_text_reading_notes.md",
    "full_text_reading_notes.json",
    "runtime_literature_graph.json",
    "runtime_literature_context_pack.md",
    "runtime_literature_context_pack.json",
    "retrieval_trace.md",
    "retrieval_trace.json",
]


def validate_slug(value: str, flag: str) -> str:
    if not SAFE_SLUG_RE.fullmatch(value):
        raise ValueError(f"{flag} must be lowercase letters, numbers, and hyphens, and must not be a path")
    return value


def parse_csv(value: str | None, default: list[str]) -> list[str]:
    if not value:
        return list(default)
    items = [item.strip() for item in value.split(",") if item.strip()]
    if not items:
        raise ValueError("comma-separated values must contain at least one item")
    return items


def build_plan(
    area_slug: str,
    recent_years: int,
    max_retrieved_papers: int,
    max_context_papers: int,
    sources: list[str],
    venue_hints: list[str],
) -> dict[str, Any]:
    if recent_years < 1:
        raise ValueError("--recent-years must be positive")
    if max_retrieved_papers < 1:
        raise ValueError("--max-retrieved-papers must be positive")
    if max_context_papers < 1:
        raise ValueError("--max-context-papers must be positive")
    if max_context_papers > max_retrieved_papers:
        raise ValueError("--max-context-papers cannot exceed --max-retrieved-papers")

    return {
        "module": MODULE_NAME,
        "module_version": MODULE_VERSION,
        "area_slug": validate_slug(area_slug, "--area-slug"),
        "recent_window_policy": {
            "type": "runtime_current_year_minus_n",
            "years": recent_years,
        },
        "max_retrieved_papers": max_retrieved_papers,
        "max_context_papers": max_context_papers,
        "sources": sources,
        "venue_hints": venue_hints,
        "source_priority": [
            "top conferences, top journals, and official proceedings",
            "public-review versions of top-venue papers",
            "canonical or high-citation papers defining the problem, baseline, benchmark, or method lineage",
            "strong workshop papers only when no top-venue equivalent exists",
            "preprints only as supplemental evidence or pointers to peer-reviewed versions",
        ],
        "query_layers": QUERY_LAYERS,
        "replaceable_components": REPLACEABLE_COMPONENTS,
        "runtime_artifacts": RUNTIME_ARTIFACTS,
        "child_skill_packaging": {
            "copy_module_reference": True,
            "copy_runtime_artifacts": False,
            "reason": "runtime literature outputs are target-paper-specific review artifacts, not reusable child-skill references",
        },
        "retrieval_rules": [
            "retrieve before making literature-grounded novelty or baseline claims",
            "open or download accessible full text for the critical related-work set before making strong novelty, baseline, or missing-comparison claims",
            "mark each work as full-text-read, partial-full-text, metadata-only, or inaccessible",
            "do not use metadata-only records as decisive evidence for novelty, expected baselines, or missing comparisons",
            "do not invent titles, authors, venues, years, URLs, citation counts, or claims",
            "cite retrieved works or state retrieval limits",
            "prioritize top-conference and top-journal papers over preprints when judging related work",
            "balance recent top-venue work with canonical/high-impact work",
            "include parent-problem and method-lineage expansion for narrow or emerging topics",
        ],
        "status": "planned",
    }


def write_plan(output_dir: Path, plan: dict[str, Any]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for folder in ["queries", "retrieved_metadata", "graph", "context_packs", "retrieval_traces"]:
        (output_dir / folder).mkdir(exist_ok=True)

    (output_dir / "runtime_literature_context_module_plan.json").write_text(
        json.dumps(plan, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    lines = [
        "# Runtime Literature Context Module Plan",
        "",
        f"- Module: `{plan['module']}`",
        f"- Version: `{plan['module_version']}`",
        f"- Area: `{plan['area_slug']}`",
        f"- Recent-window policy: `{plan['recent_window_policy']}`",
        f"- Max retrieved papers: `{plan['max_retrieved_papers']}`",
        f"- Max context papers: `{plan['max_context_papers']}`",
        "",
        "## Sources",
    ]
    lines.extend(f"- {source}" for source in plan["sources"])
    lines.extend(["", "## Venue Hints"])
    lines.extend(f"- {venue}" for venue in plan["venue_hints"] or ["not configured"])
    lines.extend(["", "## Source Priority"])
    lines.extend(f"{idx}. {item}" for idx, item in enumerate(plan["source_priority"], 1))
    lines.extend(["", "## Query Layers"])
    lines.extend(f"- {layer}" for layer in plan["query_layers"])
    lines.extend(["", "## Replaceable Components"])
    lines.extend(f"- `{name}`: {description}" for name, description in plan["replaceable_components"].items())
    lines.extend(["", "## Runtime Artifacts"])
    lines.extend(f"- `{artifact}`" for artifact in plan["runtime_artifacts"])
    lines.extend(["", "## Retrieval Rules"])
    lines.extend(f"- {rule}" for rule in plan["retrieval_rules"])
    (output_dir / "runtime_literature_context_module_plan.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--area-slug", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--recent-years", type=int, default=5)
    parser.add_argument("--max-retrieved-papers", type=int, default=80)
    parser.add_argument("--max-context-papers", type=int, default=20)
    parser.add_argument("--sources", help="Comma-separated source names.")
    parser.add_argument("--venue-hints", help="Comma-separated venue hints.")
    args = parser.parse_args(argv)

    plan = build_plan(
        area_slug=args.area_slug,
        recent_years=args.recent_years,
        max_retrieved_papers=args.max_retrieved_papers,
        max_context_papers=args.max_context_papers,
        sources=parse_csv(args.sources, DEFAULT_SOURCES),
        venue_hints=parse_csv(args.venue_hints, []),
    )
    write_plan(Path(args.output_dir), plan)
    print(Path(args.output_dir).resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
