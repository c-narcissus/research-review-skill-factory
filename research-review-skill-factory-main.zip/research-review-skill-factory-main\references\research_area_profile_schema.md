# Research Area Profile Schema

Use this schema before generating a custom area reviewer skill.

```json
{
  "area_name": "",
  "area_slug": "",
  "target_venues": ["ICLR"],
  "evidence_strategy": "openreview_first",
  "year_window": [],
  "min_reviewed_papers_per_area": 20,
  "one_sentence_scope": "",
  "research_fields": {
    "narrow": [],
    "parent": [],
    "broad": []
  },
  "problem_families": [],
  "method_families": [],
  "theory_objects": [],
  "datasets_and_settings": [],
  "baseline_families": [],
  "metrics": [],
  "openreview_queries": [],
  "openreview_sufficiency": {},
  "contrastive_sample_sources": {
    "high_level": [],
    "general_level": []
  },
  "contrastive_module": "high_throughput_pair_validation",
  "contrastive_module_config": {},
  "contrastive_min_pair_reviews_per_area": 20,
  "contrastive_pair_review_summary": {},
  "deep_read_matched_contrastive_summary": {},
  "contrastive_taste_axes": [],
  "runtime_literature_context_module": {
    "enabled": true,
    "recent_years": 5,
    "max_context_papers": 20,
    "preferred_sources": [],
    "venue_hints": [],
    "source_priority": [
      "top conferences",
      "top journals",
      "official proceedings",
      "canonical high-impact work",
      "preprints as supplemental fallback"
    ],
    "query_layers": []
  },
  "expected_review_categories": [],
  "subtle_logic_checks": [],
  "evidence_limitations": []
}
```

## Query Planning

Create 8-20 queries that cover:

- exact research area phrase;
- each problem family;
- each method family;
- important theory objects;
- benchmark or setting keywords;
- closest baseline families;
- broader fallback fields.

Example for robust representation learning under distribution shift:

- `robust representation learning`
- `representation learning under distribution shift`
- `self-supervised representation learning robustness`
- `distribution shift benchmark`
- `out-of-distribution generalization`
- `representation learning theory`
- `spectral methods representation learning`
- `contrastive representation learning`
- `non-contrastive representation learning`
- `robustness evaluation benchmark`

## Evidence Strategy

Default to `openreview_first`.

- Use the runtime current year and two previous years for `year_window` unless the user specifies years.
- Set `min_reviewed_papers_per_area` to `20` unless the user explicitly changes it.
- Fill `openreview_sufficiency` from `evidence_summary.json`.
- If the area fails the gate, fill `contrastive_sample_sources`, set `contrastive_module`, complete the selected contrastive module, and then fill `contrastive_taste_axes`.
- Use `contrastive_module = "high_throughput_pair_validation"` for the default train/validation pair workflow.
- Use `contrastive_module = "deep_read_matched_contrastive"` for curated deep-reading workflows where selected high-level papers are paired one-to-one with same-area or related general-level papers. Put aggregate counts in `deep_read_matched_contrastive_summary`, not detailed report content.
- Keep `runtime_literature_context_module.enabled = true` unless the generated skill is explicitly offline-only. This module is used later by the child skill while reviewing a target paper; it is not a static training artifact.
- Configure `venue_hints` with top conferences and journals for the target field. Runtime related-work retrieval should prioritize top-conference, top-journal, official-proceedings, and canonical/high-impact papers; preprints are supplemental fallback evidence, not the main basis for novelty or baseline judgments.
