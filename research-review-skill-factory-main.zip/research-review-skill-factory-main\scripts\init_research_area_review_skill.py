#!/usr/bin/env python3
"""Create a research-area-specific review skill from an area profile JSON spec."""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any


MIT0 = """MIT No Attribution

Copyright 2026

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

SKILL_NAME_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$")
EVIDENCE_MODES = {"openreview", "contrastive", "hybrid"}


def slugify(text: str, fallback: str = "research-area") -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    normalized = re.sub(r"-{2,}", "-", normalized)
    return normalized[:48].strip("-") or fallback


def validate_skill_name(skill_name: str) -> str:
    skill_path = Path(skill_name)
    if skill_path.is_absolute() or skill_path.drive or len(skill_path.parts) != 1:
        raise ValueError("--skill-name must be a single directory name, not a path")
    if skill_name in {".", ".."}:
        raise ValueError("--skill-name must not be '.' or '..'")
    if not SKILL_NAME_RE.fullmatch(skill_name):
        raise ValueError(
            "--skill-name must be 1-64 characters of lowercase letters, numbers, "
            "or hyphens, and must start and end with a letter or number"
        )
    return skill_name


def read_spec(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("Spec must be a JSON object")
    return data


def list_md(values: Any) -> str:
    if not values:
        return "- not reported"
    if isinstance(values, str):
        values = [values]
    if isinstance(values, dict):
        return "```json\n" + json.dumps(values, ensure_ascii=False, indent=2) + "\n```"
    return "\n".join(f"- {value}" for value in values)


def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def mode_includes_openreview(evidence_mode: str) -> bool:
    return evidence_mode in {"openreview", "hybrid"}


def mode_includes_contrastive(evidence_mode: str) -> bool:
    return evidence_mode in {"contrastive", "hybrid"}


def build_required_reading(evidence_mode: str) -> str:
    items = ["Read `references/research_area_profile.md`."]
    if mode_includes_openreview(evidence_mode):
        items.append("Read `references/openreview_review_response_bank.md`.")
    if mode_includes_contrastive(evidence_mode):
        items.append("Read `references/contrastive_taste_profile.md`.")
        items.append("Read `references/paper_review_rubric_for_contrastive.md`.")
        items.append("Read `references/privacy_and_anonymization_rules.md`.")
    items.append("Read `references/runtime_literature_context_module.md` and follow its full-text reading gate.")
    items.extend(
        [
            "Read `references/review_output_contract.md`.",
            "Read `references/subtle_logic_flaws.md`.",
            "Then inspect the target paper.",
        ]
    )
    return "\n".join(f"{idx}. {item}" for idx, item in enumerate(items, 1))


def build_skill_md(skill_name: str, spec: dict[str, Any], evidence_mode: str) -> str:
    area_name = spec.get("area_name") or skill_name
    scope = spec.get("one_sentence_scope") or "not reported"
    title_suffix = {
        "openreview": "Reviewer OpenReview",
        "contrastive": "Reviewer Contrastive",
        "hybrid": "Reviewer Hybrid",
    }[evidence_mode]
    precedent = {
        "openreview": "OpenReview-derived reviewer concern patterns",
        "contrastive": "contrastive high-level-vs-general sample taste patterns",
        "hybrid": "OpenReview-derived concerns and contrastive sample taste patterns",
    }[evidence_mode]
    description = (
        f"Review papers in the research area '{area_name}' using a custom area profile, "
        f"{precedent}, subtle logic flaw checks, "
        "and rebuttal/revision planning. Use for papers in this field/problem family."
    )
    return f"""---
name: {skill_name}
description: {description}
license: MIT-0
---

# {area_name} {title_suffix}

Use this area-specific skill to review papers in this research field or problem family.

Scope: {scope}

Evidence mode: `{evidence_mode}`

## Required Reading Order

{build_required_reading(evidence_mode)}

## Review Workflow

1. Place the target paper inside the area map.
2. Match the paper's claims and modules to the local precedent artifacts.
3. Build a runtime literature context pack from the target paper's related work, problem, methods, baselines, and claims unless the user disables retrieval.
4. For the nearest related works that affect novelty, baseline expectations, or missing comparisons, obtain and read the accessible full text whenever possible; record full-text reading notes, or mark the work `metadata-only` when access fails.
5. Generate area-specific review concerns and questions using static precedent plus runtime literature context.
6. Audit novelty, A+B incrementality, baselines, reproducibility, and subtle logic flaws.
7. Produce a standalone subtle logic flaw audit table; do not bury these checks only inside the weakness list.
8. Produce rebuttal strategy and light/moderate/major revision advice.

## Evidence Discipline

- Separate target-paper evidence, OpenReview precedent, and reviewer inference.
- Separate runtime retrieved literature from bundled/static precedent.
- Separate full-text-read literature from metadata-only literature; do not use metadata-only records for strong novelty, baseline, or missing-comparison claims.
- Cite OpenReview precedent by year, status, title, forum URL, and note type.
- Cite runtime retrieved papers when using them to judge novelty, baseline expectations, or missing comparisons.
- Cite contrastive precedent through the final taste profile axes, aggregate support, and stated limitations.
- State retrieval and full-text access limits explicitly when the review relies on target-paper evidence only.
- Mark missing paper details as `not reported`.
- Do not paste raw reviews.
- Do not include private source maps, paper titles, authors, URLs, paths, publication identifiers, preprint registry IDs, or filenames in contrastive references.
"""


def build_profile_md(spec: dict[str, Any]) -> str:
    fields = spec.get("research_fields", {})
    return f"""# Research Area Profile

## Area Name

{spec.get('area_name', 'not reported')}

## One-Sentence Scope

{spec.get('one_sentence_scope', 'not reported')}

## Target Venues

{list_md(spec.get('target_venues'))}

## Evidence Strategy

{spec.get('evidence_strategy', 'openreview_first')}

## Year Window

{list_md(spec.get('year_window'))}

## Minimum Reviewed Papers Per Area

{spec.get('min_reviewed_papers_per_area', 20)}

## Research Fields

Narrow:
{list_md(fields.get('narrow'))}

Parent:
{list_md(fields.get('parent'))}

Broad:
{list_md(fields.get('broad'))}

## Problem Families

{list_md(spec.get('problem_families'))}

## Method Families

{list_md(spec.get('method_families'))}

## Theory Objects

{list_md(spec.get('theory_objects'))}

## Datasets And Settings

{list_md(spec.get('datasets_and_settings'))}

## Baseline Families

{list_md(spec.get('baseline_families'))}

## Metrics

{list_md(spec.get('metrics'))}

## OpenReview Queries

{list_md(spec.get('openreview_queries'))}

## OpenReview Sufficiency

{list_md(spec.get('openreview_sufficiency'))}

## Contrastive Sample Sources

High Level:
{list_md((spec.get('contrastive_sample_sources') or {}).get('high_level'))}

General Level:
{list_md((spec.get('contrastive_sample_sources') or {}).get('general_level'))}

## Contrastive Minimum Pair Reviews Per Area

{spec.get('contrastive_min_pair_reviews_per_area', 20)}

## Contrastive Pair Review Summary

{list_md(spec.get('contrastive_pair_review_summary'))}

## Contrastive Taste Axes

{list_md(spec.get('contrastive_taste_axes'))}

## Runtime Literature Context Module

{list_md(spec.get('runtime_literature_context_module') or {'enabled': True})}

## Expected Review Categories

{list_md(spec.get('expected_review_categories'))}

## Subtle Logic Checks

{list_md(spec.get('subtle_logic_checks'))}

## Evidence Limitations

{list_md(spec.get('evidence_limitations'))}
"""


REVIEW_CONTRACT = """# Review Output Contract

Produce:

1. Summary and area placement.
2. Strengths tied to area-specific scientific goals.
3. Weaknesses ranked by decision impact.
4. Area precedent mapping from OpenReview, contrastive samples, or both.
5. Runtime related-literature context mapping, separating full-text-read works from metadata-only works.
6. Full-text reading coverage statement for nearest related work and expected baselines.
7. Claim-support matrix.
8. A+B / incremental novelty audit.
9. Standalone subtle logic flaw audit.
10. Reviewer questions.
11. Rebuttal plan.
12. Light, moderate, and major revision advice.
13. Evidence appendix.

For each weakness:

| Weakness | Target-paper evidence | Area precedent | Why it matters | Required fix | Response class |
| --- | --- | --- | --- | --- | --- |

Response class: `text clarification`, `minor revision`, `new experiment`, `major revision`, or `insufficient`.

For the standalone subtle logic flaw audit, use:

| Flaw type | Where it appears | Why it matters | Evidence needed | Review wording | Revision path |
| --- | --- | --- | --- | --- | --- |

If a checklist item does not apply, mark it `not applicable` with a short reason. Do not omit the section.
"""


def copy_or_write(path: Path, source: str | None, placeholder: str) -> None:
    if source:
        if Path(source).name == "private_source_map.json":
            raise ValueError("private_source_map.json must not be copied into a child skill")
        shutil.copyfile(Path(source), path)
    else:
        write(path, placeholder)


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", required=True, help="Research area profile JSON spec.")
    parser.add_argument("--output-dir", required=True, help="Directory where the child skill folder will be created.")
    parser.add_argument("--skill-name", help="Override generated child skill name.")
    parser.add_argument(
        "--evidence-mode",
        choices=sorted(EVIDENCE_MODES),
        default="openreview",
        help="Evidence files to include in the child skill.",
    )
    parser.add_argument("--bank", help="Path to curated OpenReview review-response bank markdown.")
    parser.add_argument("--contrastive-profile", help="Path to contrastive_taste_profile markdown.")
    parser.add_argument("--rationale-report", help="Deprecated external-only artifact; not copied into child skills.")
    parser.add_argument("--pair-plan", help="Deprecated external-only artifact; not copied into child skills.")
    parser.add_argument("--pair-review-bank", help="Deprecated external-only artifact; not copied into child skills.")
    parser.add_argument("--sample-manifest", help="Deprecated external-only artifact; not copied into child skills.")
    parser.add_argument("--paper-review-rubric", help="Path to paper_review_rubric_for_contrastive markdown.")
    parser.add_argument("--privacy-rules", help="Path to privacy_and_anonymization_rules markdown.")
    parser.add_argument("--subtle-logic", help="Path to subtle logic flaws markdown.")
    args = parser.parse_args(argv)

    spec = read_spec(Path(args.spec))
    base_slug = spec.get("area_slug") or slugify(spec.get("area_name", "research-area"))
    if args.skill_name:
        skill_name = validate_skill_name(args.skill_name)
    else:
        skill_name = f"{slugify(base_slug)}-reviewer-openreview"
    if len(skill_name) > 64:
        skill_name = skill_name[:64].strip("-")
    skill_name = validate_skill_name(skill_name)

    output_dir = Path(args.output_dir).resolve()
    skill_dir = (output_dir / skill_name).resolve()
    try:
        skill_dir.relative_to(output_dir)
    except ValueError as exc:
        raise ValueError("Resolved skill directory escapes --output-dir") from exc
    if skill_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing skill directory: {skill_dir}")

    write(skill_dir / "SKILL.md", build_skill_md(skill_name, spec, args.evidence_mode))
    write(skill_dir / "references" / "research_area_profile.md", build_profile_md(spec))
    write(skill_dir / "references" / "review_output_contract.md", REVIEW_CONTRACT)
    write(
        skill_dir / "agents" / "openai.yaml",
        "interface:\n"
        f"  display_name: \"{spec.get('area_name', skill_name)} Reviewer\"\n"
        f"  short_description: \"Custom {args.evidence_mode} area review skill.\"\n"
        f"  default_prompt: \"Use ${skill_name} to review this paper in the target research area.\"\n",
    )
    write(skill_dir / "LICENSE.txt", MIT0)
    write(
        skill_dir / "_meta.json",
        json.dumps(
            {
                "name": skill_name,
                "version": "1.0.0",
                "license": "MIT-0",
                "source_meta_skill": "research-review-skill-factory",
                "area_name": spec.get("area_name", ""),
                "evidence_mode": args.evidence_mode,
            },
            ensure_ascii=False,
            indent=2,
        ),
    )

    root = Path(__file__).resolve().parents[1]
    subtle = Path(args.subtle_logic) if args.subtle_logic else root / "references" / "subtle_logic_flaws.md"
    shutil.copyfile(subtle, skill_dir / "references" / "subtle_logic_flaws.md")
    shutil.copyfile(
        root / "references" / "runtime_literature_context_module.md",
        skill_dir / "references" / "runtime_literature_context_module.md",
    )

    if mode_includes_openreview(args.evidence_mode):
        bank = Path(args.bank) if args.bank else root / "references" / "generated_area_review_skill_contract.md"
        shutil.copyfile(bank, skill_dir / "references" / "openreview_review_response_bank.md")

    if mode_includes_contrastive(args.evidence_mode):
        copy_or_write(
            skill_dir / "references" / "contrastive_taste_profile.md",
            args.contrastive_profile,
            "# Contrastive Reviewer Taste Profile\n\nnot reported\n",
        )
        copy_or_write(
            skill_dir / "references" / "paper_review_rubric_for_contrastive.md",
            args.paper_review_rubric,
            (root / "references" / "paper_review_rubric_for_contrastive.md").read_text(encoding="utf-8"),
        )
        copy_or_write(
            skill_dir / "references" / "privacy_and_anonymization_rules.md",
            args.privacy_rules,
            (root / "references" / "privacy_and_anonymization_rules.md").read_text(encoding="utf-8"),
        )

    print(skill_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
