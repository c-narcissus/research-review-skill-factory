from __future__ import annotations

import importlib.util
import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "init_research_area_review_skill.py"
SPEC = importlib.util.spec_from_file_location("init_research_area_review_skill", SCRIPT)
assert SPEC is not None
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class InitResearchAreaReviewSkillTest(unittest.TestCase):
    def test_rejects_path_traversal_skill_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            spec_path = tmp_path / "spec.json"
            bank_path = tmp_path / "bank.md"
            logic_path = tmp_path / "logic.md"
            output_dir = tmp_path / "out"

            spec_path.write_text('{"area_name": "Test Area"}', encoding="utf-8")
            bank_path.write_text("# Bank\n", encoding="utf-8")
            logic_path.write_text("# Logic\n", encoding="utf-8")

            with self.assertRaises(ValueError):
                MODULE.main(
                    [
                        "--spec",
                        str(spec_path),
                        "--output-dir",
                        str(output_dir),
                        "--skill-name",
                        "../outside",
                        "--bank",
                        str(bank_path),
                        "--subtle-logic",
                        str(logic_path),
                    ]
                )

            self.assertFalse((tmp_path / "outside").exists())

    def test_accepts_slug_skill_name(self) -> None:
        self.assertEqual(
            MODULE.validate_skill_name("graph-reviewer-openreview"),
            "graph-reviewer-openreview",
        )

    def test_generates_skill_with_valid_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            spec_path = tmp_path / "spec.json"
            bank_path = tmp_path / "bank.md"
            logic_path = tmp_path / "logic.md"
            output_dir = tmp_path / "out"

            spec_path.write_text('{"area_name": "Test Area"}', encoding="utf-8")
            bank_path.write_text("# Bank\n", encoding="utf-8")
            logic_path.write_text("# Logic\n", encoding="utf-8")

            with redirect_stdout(io.StringIO()):
                result = MODULE.main(
                    [
                        "--spec",
                        str(spec_path),
                        "--output-dir",
                        str(output_dir),
                        "--skill-name",
                        "test-area-reviewer",
                        "--bank",
                        str(bank_path),
                        "--subtle-logic",
                        str(logic_path),
                    ]
                )

            skill_dir = output_dir / "test-area-reviewer"
            self.assertEqual(result, 0)
            self.assertTrue((skill_dir / "SKILL.md").exists())
            self.assertTrue(
                (skill_dir / "references" / "openreview_review_response_bank.md").exists()
            )
            self.assertTrue((skill_dir / "references" / "runtime_literature_context_module.md").exists())
            skill_text = (skill_dir / "SKILL.md").read_text(encoding="utf-8")
            self.assertIn("runtime literature context", skill_text)
            self.assertIn("full-text reading gate", skill_text)
            self.assertIn("standalone subtle logic flaw audit", skill_text)
            contract_text = (skill_dir / "references" / "review_output_contract.md").read_text(encoding="utf-8")
            self.assertIn("metadata-only", contract_text)
            self.assertIn("Do not omit the section", contract_text)

    def test_generates_contrastive_mode_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            spec_path = tmp_path / "spec.json"
            profile_path = tmp_path / "contrastive.md"
            manifest_path = tmp_path / "manifest.md"
            pair_plan_path = tmp_path / "pair_plan.md"
            pair_bank_path = tmp_path / "pair_bank.md"
            rationale_path = tmp_path / "rationale.md"
            logic_path = tmp_path / "logic.md"
            output_dir = tmp_path / "out"

            spec_path.write_text('{"area_name": "Sparse Area"}', encoding="utf-8")
            profile_path.write_text("# Contrastive\n", encoding="utf-8")
            manifest_path.write_text("# Manifest\n", encoding="utf-8")
            pair_plan_path.write_text("# Pair Plan\n", encoding="utf-8")
            pair_bank_path.write_text("# Pair Bank\n", encoding="utf-8")
            rationale_path.write_text("# Rationale\n", encoding="utf-8")
            logic_path.write_text("# Logic\n", encoding="utf-8")

            with redirect_stdout(io.StringIO()):
                result = MODULE.main(
                    [
                        "--spec",
                        str(spec_path),
                        "--output-dir",
                        str(output_dir),
                        "--skill-name",
                        "sparse-area-reviewer",
                        "--evidence-mode",
                        "contrastive",
                        "--contrastive-profile",
                        str(profile_path),
                        "--pair-plan",
                        str(pair_plan_path),
                        "--pair-review-bank",
                        str(pair_bank_path),
                        "--rationale-report",
                        str(rationale_path),
                        "--sample-manifest",
                        str(manifest_path),
                        "--subtle-logic",
                        str(logic_path),
                    ]
                )

            skill_dir = output_dir / "sparse-area-reviewer"
            self.assertEqual(result, 0)
            self.assertTrue((skill_dir / "references" / "contrastive_taste_profile.md").exists())
            self.assertTrue((skill_dir / "references" / "paper_review_rubric_for_contrastive.md").exists())
            self.assertTrue((skill_dir / "references" / "privacy_and_anonymization_rules.md").exists())
            self.assertTrue((skill_dir / "references" / "runtime_literature_context_module.md").exists())
            self.assertFalse((skill_dir / "references" / "openreview_review_response_bank.md").exists())
            self.assertFalse((skill_dir / "references" / "sample_source_manifest.md").exists())
            self.assertFalse((skill_dir / "references" / "contrastive_pair_plan.md").exists())
            self.assertFalse((skill_dir / "references" / "pair_review_bank.md").exists())
            self.assertFalse((skill_dir / "references" / "contrastive_inference_rationale_report.md").exists())
            self.assertFalse((skill_dir / "references" / "private_source_map.json").exists())

    def test_generates_hybrid_mode_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            spec_path = tmp_path / "spec.json"
            bank_path = tmp_path / "bank.md"
            profile_path = tmp_path / "contrastive.md"
            manifest_path = tmp_path / "manifest.md"
            pair_plan_path = tmp_path / "pair_plan.md"
            pair_bank_path = tmp_path / "pair_bank.md"
            rationale_path = tmp_path / "rationale.md"
            logic_path = tmp_path / "logic.md"
            output_dir = tmp_path / "out"

            spec_path.write_text('{"area_name": "Hybrid Area"}', encoding="utf-8")
            bank_path.write_text("# Bank\n", encoding="utf-8")
            profile_path.write_text("# Contrastive\n", encoding="utf-8")
            manifest_path.write_text("# Manifest\n", encoding="utf-8")
            pair_plan_path.write_text("# Pair Plan\n", encoding="utf-8")
            pair_bank_path.write_text("# Pair Bank\n", encoding="utf-8")
            rationale_path.write_text("# Rationale\n", encoding="utf-8")
            logic_path.write_text("# Logic\n", encoding="utf-8")

            with redirect_stdout(io.StringIO()):
                result = MODULE.main(
                    [
                        "--spec",
                        str(spec_path),
                        "--output-dir",
                        str(output_dir),
                        "--skill-name",
                        "hybrid-area-reviewer",
                        "--evidence-mode",
                        "hybrid",
                        "--bank",
                        str(bank_path),
                        "--contrastive-profile",
                        str(profile_path),
                        "--pair-plan",
                        str(pair_plan_path),
                        "--pair-review-bank",
                        str(pair_bank_path),
                        "--rationale-report",
                        str(rationale_path),
                        "--sample-manifest",
                        str(manifest_path),
                        "--subtle-logic",
                        str(logic_path),
                    ]
                )

            skill_dir = output_dir / "hybrid-area-reviewer"
            self.assertEqual(result, 0)
            self.assertTrue((skill_dir / "references" / "openreview_review_response_bank.md").exists())
            self.assertTrue((skill_dir / "references" / "contrastive_taste_profile.md").exists())
            self.assertTrue((skill_dir / "references" / "paper_review_rubric_for_contrastive.md").exists())
            self.assertTrue((skill_dir / "references" / "privacy_and_anonymization_rules.md").exists())
            self.assertFalse((skill_dir / "references" / "sample_source_manifest.md").exists())
            self.assertFalse((skill_dir / "references" / "contrastive_inference_rationale_report.md").exists())
            self.assertFalse((skill_dir / "references" / "pair_review_bank.md").exists())

    def test_rejects_private_source_map_copy(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            spec_path = tmp_path / "spec.json"
            private_map = tmp_path / "private_source_map.json"
            logic_path = tmp_path / "logic.md"
            output_dir = tmp_path / "out"

            spec_path.write_text('{"area_name": "Sparse Area"}', encoding="utf-8")
            private_map.write_text("{}", encoding="utf-8")
            logic_path.write_text("# Logic\n", encoding="utf-8")

            with self.assertRaises(ValueError):
                MODULE.main(
                    [
                        "--spec",
                        str(spec_path),
                        "--output-dir",
                        str(output_dir),
                        "--skill-name",
                        "private-map-reviewer",
                        "--evidence-mode",
                        "contrastive",
                        "--contrastive-profile",
                        str(private_map),
                        "--subtle-logic",
                        str(logic_path),
                    ]
                )


if __name__ == "__main__":
    unittest.main()
