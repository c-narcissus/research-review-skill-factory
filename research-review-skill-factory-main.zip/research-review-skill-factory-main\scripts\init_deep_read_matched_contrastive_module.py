#!/usr/bin/env python3
"""Initialize a replaceable deep-read matched contrastive module plan."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any


MODULE_NAME = "deep_read_matched_contrastive"
MODULE_VERSION = "1.0"
PAIRING_POLICIES = {"one_to_one_no_reuse", "one_to_one_allow_general_reuse"}
SAFE_NAME_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,78}[a-z0-9])?$")

EXTERNAL_ARTIFACTS = [
    "deep_read_reports/",
    "matched_pair_plan.md",
    "matched_pair_plan.json",
    "pair_analyses/",
    "pairwise_analyses.json",
    "contrastive_inference_rationale_report.md",
    "contrastive_inference_rationale_report.json",
    "reading_coverage_summary.md",
    "private_source_map.json",
]

CHILD_SAFE_ARTIFACTS = [
    "contrastive_taste_profile.md",
    "paper_review_rubric_for_contrastive.md",
    "privacy_and_anonymization_rules.md",
    "aggregate counts and limitations in research_area_profile.md",
]

PRIVACY_FORBIDDEN_IN_CHILD = [
    "paper titles",
    "author names",
    "original filenames",
    "URLs",
    "absolute or relative local paths",
    "DOI strings",
    "preprint identifiers",
    "raw paper text",
    "private source maps",
    "sample IDs",
    "pair IDs",
    "deep-read reports",
    "pair analysis reports",
]

REPLACEABLE_COMPONENTS = {
    "domain_adapter": "area-specific vocabulary, subfields, benchmarks, metrics, and failure modes",
    "deep_reader": "single-paper anonymized deep-reading prompt or tool",
    "subfield_matcher": "same-area or related-subfield high/general matching logic",
    "pair_comparator": "pair-level explanation of high-level strengths and general-level gaps",
    "taste_synthesizer": "aggregate reviewer-taste axis builder",
    "privacy_filter": "child-skill artifact redaction and whitelist packager",
}


def validate_slug(value: str, flag: str) -> str:
    if not SAFE_NAME_RE.fullmatch(value):
        raise ValueError(f"{flag} must be lowercase letters, numbers, and hyphens, and must not be a path")
    return value


def build_plan(
    area_slug: str,
    high_count: int,
    general_count: int,
    target_pair_count: int | None,
    pairing_policy: str,
) -> dict[str, Any]:
    if high_count <= 0:
        raise ValueError("--selected-high-count must be positive")
    if general_count <= 0:
        raise ValueError("--selected-general-count must be positive")
    if pairing_policy not in PAIRING_POLICIES:
        raise ValueError(f"--pairing-policy must be one of {sorted(PAIRING_POLICIES)}")
    pair_count = target_pair_count if target_pair_count is not None else high_count
    if pair_count <= 0:
        raise ValueError("--target-pair-count must be positive")
    if pair_count > high_count:
        raise ValueError("target pair count cannot exceed selected high-level count")
    if pairing_policy == "one_to_one_no_reuse" and pair_count > general_count:
        raise ValueError("one-to-one no-reuse matching requires at least as many general-level samples as pairs")

    return {
        "module": MODULE_NAME,
        "module_version": MODULE_VERSION,
        "area_slug": validate_slug(area_slug, "--area-slug"),
        "target_pair_count": pair_count,
        "pairing_policy": pairing_policy,
        "selected_high_level_count": high_count,
        "selected_general_level_count": general_count,
        "external_artifacts": EXTERNAL_ARTIFACTS,
        "child_safe_artifacts": CHILD_SAFE_ARTIFACTS,
        "replaceable_components": REPLACEABLE_COMPONENTS,
        "privacy_forbidden_in_child": PRIVACY_FORBIDDEN_IN_CHILD,
        "workflow": [
            "anonymize sources and keep a local-only private source map",
            "deep-read selected high-level and matched general-level papers as single-paper reports",
            "match high/general samples by same area or related subfield",
            "compare each pair using area-specific review criteria",
            "synthesize aggregate reviewer-taste axes",
            "copy only child-safe aggregate profile files into the generated skill",
        ],
        "status": "planned",
    }


def write_plan(output_dir: Path, plan: dict[str, Any]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    for folder in ["deep_read_reports", "pair_analyses"]:
        (output_dir / folder).mkdir(exist_ok=True)

    (output_dir / "deep_read_matched_contrastive_module_plan.json").write_text(
        json.dumps(plan, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    lines = [
        "# Deep-Read Matched Contrastive Module Plan",
        "",
        f"- Module: `{plan['module']}`",
        f"- Version: `{plan['module_version']}`",
        f"- Area: `{plan['area_slug']}`",
        f"- Target pairs: `{plan['target_pair_count']}`",
        f"- Pairing policy: `{plan['pairing_policy']}`",
        f"- Selected high-level count: `{plan['selected_high_level_count']}`",
        f"- Selected general-level count: `{plan['selected_general_level_count']}`",
        "",
        "## Replaceable Components",
    ]
    lines.extend(f"- `{name}`: {description}" for name, description in plan["replaceable_components"].items())
    lines.extend(["", "## External Artifacts"])
    lines.extend(f"- `{item}`" for item in plan["external_artifacts"])
    lines.extend(["", "## Child-Safe Artifacts"])
    lines.extend(f"- `{item}`" for item in plan["child_safe_artifacts"])
    lines.extend(["", "## Forbidden In Child Skill"])
    lines.extend(f"- {item}" for item in plan["privacy_forbidden_in_child"])
    lines.extend(["", "## Workflow"])
    lines.extend(f"{idx}. {step}" for idx, step in enumerate(plan["workflow"], 1))
    (output_dir / "deep_read_matched_contrastive_module_plan.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--area-slug", required=True)
    parser.add_argument("--selected-high-count", type=int, required=True)
    parser.add_argument("--selected-general-count", type=int, required=True)
    parser.add_argument("--target-pair-count", type=int)
    parser.add_argument("--pairing-policy", default="one_to_one_no_reuse", choices=sorted(PAIRING_POLICIES))
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args(argv)

    plan = build_plan(
        args.area_slug,
        args.selected_high_count,
        args.selected_general_count,
        args.target_pair_count,
        args.pairing_policy,
    )
    write_plan(Path(args.output_dir), plan)
    print(Path(args.output_dir).resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
