from __future__ import annotations

import importlib.util
import io
import json
import re
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_script(name: str):
    script = ROOT / "scripts" / name
    spec = importlib.util.spec_from_file_location(name, script)
    assert spec is not None
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


COLLECT = load_script("collect_contrastive_samples.py")
SELECT = load_script("select_contrastive_pairs.py")
INIT_BANK = load_script("init_pair_review_bank.py")
BUILD = load_script("build_contrastive_taste_profile.py")
DEEP_READ = load_script("deep_read_contrastive_pairs.py")
INIT_DEEP_MATCHED = load_script("init_deep_read_matched_contrastive_module.py")
INIT_RUNTIME_LIT = load_script("init_runtime_literature_context_module.py")


def write_samples(root: Path, level: str, area: str, count: int) -> Path:
    folder = root / level / area
    folder.mkdir(parents=True)
    suffix = ".md" if level == "high" else ".pdf"
    for idx in range(count):
        path = folder / f"{level}-paper-{idx:02d}{suffix}"
        if suffix == ".md":
            path.write_text("# sample\n", encoding="utf-8")
        else:
            path.write_bytes(b"%PDF-1.4\n")
    return root / level


def completed_bank(area: str = "area-one", count: int = 20, concern_name: str = "mechanism evidence") -> dict[str, object]:
    return {
        "pair_reviews": [
            {
                "pair_id": f"{area}:pair_{idx + 1:03d}",
                "area_slug": area,
                "high_sample_id": f"{area}:H{idx + 1:03d}",
                "general_sample_id": f"{area}:G{idx + 1:03d}",
                "high_review": {"claim_evidence_alignment": "strong mechanism evidence"},
                "general_review": {"claim_evidence_alignment": "missing mechanism evidence"},
                "pairwise_difference": ["high sample supports mechanism; general sample leaves mechanism underspecified"],
                "inferred_reviewer_concerns": [
                    {
                        "concern": concern_name,
                        "high_level_signal": "explicit mechanism evidence",
                        "general_level_gap": "mechanism underspecified",
                        "why": "the contrast repeats across completed pair reviews",
                    }
                ],
                "completed": True,
            }
            for idx in range(count)
        ]
    }


def mixed_validation_bank(area: str = "area-one", success_count: int = 19, total: int = 21) -> dict[str, object]:
    pair_reviews = []
    for idx in range(total):
        concern_name = "mechanism evidence" if idx < success_count else f"unseen concern {idx}"
        pair_reviews.append(
            {
                "pair_id": f"{area}:validation_pair_{idx + 1:03d}",
                "area_slug": area,
                "high_sample_id": f"{area}:H{idx + 1:03d}",
                "general_sample_id": f"{area}:G{idx + 1:03d}",
                "high_review": {"claim_evidence_alignment": "strong evidence"},
                "general_review": {"claim_evidence_alignment": "missing evidence"},
                "pairwise_difference": ["high sample supports concern; general sample underspecifies it"],
                "inferred_reviewer_concerns": [
                    {
                        "concern": concern_name,
                        "high_level_signal": "explicit evidence",
                        "general_level_gap": "underspecified evidence",
                        "why": "the contrast appears in held-out validation",
                    }
                ],
                "completed": True,
            }
        )
    return {"pair_reviews": pair_reviews}


def fake_deep_features(sample_id: str, private_samples: dict[str, object]) -> dict[str, object]:
    return {
        "sample_id": sample_id,
        "reading_coverage": {
            "page_count": 10,
            "pages_read": 10,
            "extracted_characters": 1000,
            "section_coverage": {
                "abstract": True,
                "introduction": True,
                "method": True,
                "experiment": True,
                "appendix": False,
                "limitation": True,
            },
        },
        "settings": ["distribution shift or heterogeneity"],
        "baseline_count": 4,
        "dataset_count": 3,
        "theory_score": 10,
        "experiment_score": 12,
        "ablation_score": 3,
        "reproducibility_score": 4,
        "limitations_score": 3,
        "claim_count": 5,
        "domain_specificity_score": 30,
        "baseline_examples": ["baseline"],
        "dataset_examples": ["cifar"],
    }


class ContrastiveScriptsTest(unittest.TestCase):
    def test_collects_anonymized_manifest_and_private_map(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            high = write_samples(tmp_path, "high", "area-one", 2)
            general = write_samples(tmp_path, "general", "area-one", 2)
            output = tmp_path / "out"

            with redirect_stdout(io.StringIO()):
                result = COLLECT.main(
                    [
                        "--high-source",
                        str(high),
                        "--general-source",
                        str(general),
                        "--output",
                        str(output),
                    ]
                )

            self.assertEqual(result, 0)
            manifest = json.loads((output / "sample_source_manifest.json").read_text(encoding="utf-8"))
            manifest_text = (output / "sample_source_manifest.md").read_text(encoding="utf-8")
            self.assertEqual(manifest["counts"]["by_area"]["area-one"]["high_level"], 2)
            self.assertEqual(manifest["samples"][0]["sample_id"], "area-one:H001")
            self.assertNotIn("high-paper", manifest_text)
            self.assertNotIn(str(high), manifest_text)
            self.assertTrue((output / "private_source_map.json").exists())

    def test_pair_selection_requires_train_and_validation_pairs_per_area(self) -> None:
        manifest = {
            "samples": [
                {"sample_id": f"area-one:H{idx:03d}", "area_slug": "area-one", "level": "high_level", "selection_status": "eligible"}
                for idx in range(1, 5)
            ]
            + [
                {"sample_id": f"area-one:G{idx:03d}", "area_slug": "area-one", "level": "general_level", "selection_status": "eligible"}
                for idx in range(1, 5)
            ]
        }
        with self.assertRaises(ValueError):
            SELECT.select_pairs(manifest, seed=7, min_train_pairs=20, validation_pairs=20, max_pairs=2000)

    def test_pair_selection_caps_at_two_thousand_and_holds_out_validation_docs(self) -> None:
        samples = []
        area = "area-one"
        samples.extend(
            {"sample_id": f"{area}:H{idx:03d}", "area_slug": area, "level": "high_level", "selection_status": "eligible"}
            for idx in range(1, 71)
        )
        samples.extend(
            {"sample_id": f"{area}:G{idx:03d}", "area_slug": area, "level": "general_level", "selection_status": "eligible"}
            for idx in range(1, 71)
        )
        manifest = {"samples": samples}
        first = SELECT.select_pairs(manifest, seed=11, min_train_pairs=20, validation_pairs=20, max_pairs=2000)
        second = SELECT.select_pairs(manifest, seed=11, min_train_pairs=20, validation_pairs=20, max_pairs=2000)
        self.assertEqual(first["pairs"], second["pairs"])
        self.assertEqual(first["area_summaries"]["area-one"]["selected_training_pairs"], 1800)
        self.assertEqual(first["area_summaries"]["area-one"]["selected_validation_pairs"], 200)
        train_ids = {pair["high_sample_id"] for pair in first["training_pairs"]} | {pair["general_sample_id"] for pair in first["training_pairs"]}
        validation_ids = {pair["high_sample_id"] for pair in first["validation_pairs"]} | {pair["general_sample_id"] for pair in first["validation_pairs"]}
        self.assertTrue(train_ids.isdisjoint(validation_ids))

    def test_pair_selection_uses_actual_possible_when_below_cap(self) -> None:
        area = "area-one"
        manifest = {
            "samples": [
                {"sample_id": f"{area}:H{idx:03d}", "area_slug": area, "level": "high_level", "selection_status": "eligible"}
                for idx in range(1, 11)
            ]
            + [
                {"sample_id": f"{area}:G{idx:03d}", "area_slug": area, "level": "general_level", "selection_status": "eligible"}
                for idx in range(1, 11)
            ]
        }
        plan = SELECT.select_pairs(manifest, seed=5, min_train_pairs=20, validation_pairs=20, max_pairs=2000)
        self.assertLess(plan["area_summaries"][area]["selected_total_pairs"], 2000)
        self.assertGreaterEqual(plan["area_summaries"][area]["selected_training_pairs"], 20)
        self.assertGreater(plan["area_summaries"][area]["selected_validation_pairs"], 20)

    def test_profile_requires_completed_twenty_pair_reviews(self) -> None:
        with self.assertRaises(ValueError):
            BUILD.build_reports(
                completed_bank(count=19),
                completed_bank(count=20),
                min_train_pairs_per_area=20,
                min_validation_pairs_per_area=21,
                evidence_mode="contrastive",
            )

    def test_validation_success_threshold_allows_ninety_percent(self) -> None:
        profile, _rationale, validation = BUILD.build_reports(
            completed_bank(count=20, concern_name="mechanism evidence"),
            mixed_validation_bank(success_count=19, total=21),
            min_train_pairs_per_area=20,
            min_validation_pairs_per_area=21,
            evidence_mode="contrastive",
            min_validation_success_rate=0.9,
        )
        summary = validation["validation_success_by_area"]["area-one"]
        self.assertTrue(validation["validation_success_passed"])
        self.assertEqual(summary["success_rate"], 0.905)
        self.assertEqual(summary["successful_pairs"], 19)
        self.assertEqual(profile["validation_success_by_area"]["area-one"]["passed"], True)

    def test_validation_success_threshold_rejects_below_ninety_percent(self) -> None:
        with self.assertRaises(ValueError):
            BUILD.build_reports(
                completed_bank(count=20, concern_name="mechanism evidence"),
                mixed_validation_bank(success_count=18, total=21),
                min_train_pairs_per_area=20,
                min_validation_pairs_per_area=21,
                evidence_mode="contrastive",
                min_validation_success_rate=0.9,
            )

    def test_builds_profile_rationale_and_validation_report(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            bank_path = tmp_path / "pair_review_bank.json"
            validation_path = tmp_path / "validation_pair_review_bank.json"
            output = tmp_path / "out"
            bank_path.write_text(json.dumps(completed_bank(), ensure_ascii=False), encoding="utf-8")
            validation_path.write_text(json.dumps(completed_bank(count=21), ensure_ascii=False), encoding="utf-8")

            with redirect_stdout(io.StringIO()):
                result = BUILD.main(
                    [
                        "--pair-review-bank",
                        str(bank_path),
                        "--validation-review-bank",
                        str(validation_path),
                        "--output-dir",
                        str(output),
                    ]
                )

            self.assertEqual(result, 0)
            profile = (output / "contrastive_taste_profile.md").read_text(encoding="utf-8")
            rationale = (output / "contrastive_inference_rationale_report.md").read_text(encoding="utf-8")
            validation = (output / "validation_report.md").read_text(encoding="utf-8")
            self.assertIn("mechanism evidence", profile)
            self.assertIn("Why this implies reviewer attention", rationale)
            self.assertIn("Supported Axes", validation)
            self.assertNotIn("http://", profile + rationale + validation)

    def test_init_pair_review_bank_templates_are_incomplete(self) -> None:
        plan = {
            "min_train_pairs": 20,
            "validation_pairs_per_area": 20,
            "random_seed": 3,
            "training_pairs": [
                {
                    "pair_id": "area-one:train_pair_001",
                    "split": "train",
                    "area_slug": "area-one",
                    "high_sample_id": "area-one:H001",
                    "general_sample_id": "area-one:G001",
                }
            ],
            "validation_pairs": [],
        }
        bank = INIT_BANK.build_bank(plan, "train")
        self.assertFalse(bank["pair_reviews"][0]["completed"])

    def test_deep_read_train_split_does_not_touch_validation_samples(self) -> None:
        plan = {
            "random_seed": 9,
            "training_pairs": [
                {
                    "pair_id": "area-one:train_pair_001",
                    "split": "train",
                    "area_slug": "area-one",
                    "high_sample_id": "area-one:H001",
                    "general_sample_id": "area-one:G001",
                }
            ],
            "validation_pairs": [
                {
                    "pair_id": "area-one:validation_pair_001",
                    "split": "validation",
                    "area_slug": "area-one",
                    "high_sample_id": "area-one:H002",
                    "general_sample_id": "area-one:G002",
                }
            ],
        }
        private_map = {
            "samples": {
                "area-one:H001": {"local_path": "train-high.pdf"},
                "area-one:G001": {"local_path": "train-general.pdf"},
                "area-one:H002": {"local_path": "validation-high.pdf"},
                "area-one:G002": {"local_path": "validation-general.pdf"},
            }
        }
        original = DEEP_READ.features
        seen: list[str] = []

        def recording_features(sample_id: str, private_samples: dict[str, object]) -> dict[str, object]:
            seen.append(sample_id)
            return fake_deep_features(sample_id, private_samples)

        try:
            DEEP_READ.features = recording_features
            DEEP_READ.build_review_bank(plan, private_map, "train")
        finally:
            DEEP_READ.features = original

        self.assertEqual(sorted(seen), ["area-one:G001", "area-one:H001"])

    def test_deep_read_single_paper_reviews_are_blind_until_pair_contrast(self) -> None:
        plan = {
            "random_seed": 9,
            "training_pairs": [
                {
                    "pair_id": "area-one:train_pair_001",
                    "split": "train",
                    "area_slug": "area-one",
                    "high_sample_id": "area-one:H001",
                    "general_sample_id": "area-one:G001",
                }
            ],
            "validation_pairs": [],
        }
        private_map = {
            "samples": {
                "area-one:H001": {"local_path": "train-high.pdf"},
                "area-one:G001": {"local_path": "train-general.pdf"},
            }
        }
        original = DEEP_READ.features
        try:
            DEEP_READ.features = fake_deep_features
            bank, _notes = DEEP_READ.build_review_bank(plan, private_map, "train")
        finally:
            DEEP_READ.features = original

        review = bank["pair_reviews"][0]
        self.assertEqual(review["protocol"], "blind_single_paper_reviews_then_label_reveal_pairwise_contrast")
        single_reviews = json.dumps(
            {"high_review": review["high_review"], "general_review": review["general_review"]},
            ensure_ascii=False,
        ).lower()
        self.assertNotRegex(single_reviews, re.compile(r"\b(high-level|general-level)\b"))
        self.assertIn("label_reveal_stage", review)

    def test_deep_read_matched_module_plan_enforces_one_to_one_counts(self) -> None:
        with self.assertRaises(ValueError):
            INIT_DEEP_MATCHED.build_plan(
                area_slug="area-one",
                high_count=3,
                general_count=2,
                target_pair_count=3,
                pairing_policy="one_to_one_no_reuse",
            )

        plan = INIT_DEEP_MATCHED.build_plan(
            area_slug="area-one",
            high_count=3,
            general_count=3,
            target_pair_count=None,
            pairing_policy="one_to_one_no_reuse",
        )
        self.assertEqual(plan["module"], "deep_read_matched_contrastive")
        self.assertEqual(plan["target_pair_count"], 3)
        self.assertIn("deep_read_reports/", plan["external_artifacts"])
        self.assertIn("contrastive_taste_profile.md", plan["child_safe_artifacts"])
        self.assertIn("pair IDs", plan["privacy_forbidden_in_child"])

    def test_deep_read_matched_module_initializer_writes_skeleton(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "module"
            result = INIT_DEEP_MATCHED.main(
                [
                    "--area-slug",
                    "area-one",
                    "--selected-high-count",
                    "4",
                    "--selected-general-count",
                    "4",
                    "--output-dir",
                    str(output),
                ]
            )
            self.assertEqual(result, 0)
            self.assertTrue((output / "deep_read_reports").is_dir())
            self.assertTrue((output / "pair_analyses").is_dir())
            plan = json.loads((output / "deep_read_matched_contrastive_module_plan.json").read_text(encoding="utf-8"))
            self.assertEqual(plan["pairing_policy"], "one_to_one_no_reuse")
            self.assertEqual(plan["target_pair_count"], 4)
            self.assertNotIn("private_source_map.json", plan["child_safe_artifacts"])

    def test_deep_read_matched_module_reference_is_domain_neutral(self) -> None:
        text = (ROOT / "references" / "deep_read_matched_contrastive_module.md").read_text(encoding="utf-8")
        forbidden_terms = [
            "fede" + "rated",
            "fede" + "rated-learning",
            r"\b" + "F" + "L" + r"\b",
            "Fed" + "Avg",
            "non" + "-IID",
            "client " + "drift",
        ]
        self.assertNotRegex(text, re.compile("|".join(forbidden_terms), re.I))

    def test_runtime_literature_context_plan_validates_limits(self) -> None:
        with self.assertRaises(ValueError):
            INIT_RUNTIME_LIT.build_plan(
                area_slug="area-one",
                recent_years=5,
                max_retrieved_papers=10,
                max_context_papers=20,
                sources=["source"],
                venue_hints=[],
            )

        plan = INIT_RUNTIME_LIT.build_plan(
            area_slug="area-one",
            recent_years=5,
            max_retrieved_papers=80,
            max_context_papers=20,
            sources=["source"],
            venue_hints=["venue"],
        )
        self.assertEqual(plan["module"], "runtime_literature_context")
        self.assertEqual(plan["recent_window_policy"]["type"], "runtime_current_year_minus_n")
        self.assertIn("parent problem", plan["query_layers"])
        self.assertIn("recent top-conference/top-journal sweep", plan["query_layers"])
        self.assertIn("full_text_reader", plan["replaceable_components"])
        self.assertIn("preprints only as supplemental evidence or pointers to peer-reviewed versions", plan["source_priority"])
        self.assertIn("prioritize top-conference and top-journal papers over preprints when judging related work", plan["retrieval_rules"])
        self.assertIn("full_text_reading_notes.md", plan["runtime_artifacts"])
        self.assertIn("do not use metadata-only records as decisive evidence for novelty, expected baselines, or missing comparisons", plan["retrieval_rules"])
        self.assertFalse(plan["child_skill_packaging"]["copy_runtime_artifacts"])

    def test_runtime_literature_context_initializer_writes_skeleton(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "runtime-lit"
            result = INIT_RUNTIME_LIT.main(
                [
                    "--area-slug",
                    "area-one",
                    "--output-dir",
                    str(output),
                    "--sources",
                    "source-a,source-b",
                    "--venue-hints",
                    "venue-a",
                ]
            )
            self.assertEqual(result, 0)
            self.assertTrue((output / "queries").is_dir())
            self.assertTrue((output / "graph").is_dir())
            self.assertTrue((output / "context_packs").is_dir())
            plan = json.loads((output / "runtime_literature_context_module_plan.json").read_text(encoding="utf-8"))
            self.assertEqual(plan["sources"], ["source-a", "source-b"])
            self.assertEqual(plan["venue_hints"], ["venue-a"])
            self.assertIn("runtime_literature_context_pack.md", plan["runtime_artifacts"])
            self.assertIn("full_text_reading_notes.json", plan["runtime_artifacts"])
            self.assertIn("top conferences, top journals, and official proceedings", plan["source_priority"])


if __name__ == "__main__":
    unittest.main()
