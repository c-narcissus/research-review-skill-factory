#!/usr/bin/env python3
"""Initialize anonymous train and validation pair review bank templates."""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Any


def read_plan(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError("Pair plan must be a JSON object.")
    return data


def empty_review() -> dict[str, Any]:
    return {
        "contribution_summary": "",
        "problem_importance": "",
        "novelty_and_incrementality": "",
        "technical_soundness": "",
        "claim_evidence_alignment": "",
        "experiments_baselines_ablations": "",
        "reproducibility": "",
        "limitations_and_overclaim": "",
        "writing_clarity": "",
        "decision_impact_weaknesses": [],
        "reading_coverage": {},
    }


def build_bank(plan: dict[str, Any], split: str = "train") -> dict[str, Any]:
    key = "training_pairs" if split == "train" else "validation_pairs"
    return {
        "generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "privacy": "anonymous review bank; do not add paper identities",
        "split": split,
        "min_train_pairs": plan.get("min_train_pairs", 20),
        "min_validation_pairs_per_area": plan.get("min_validation_pairs_per_area", 21),
        "validation_fraction": plan.get("validation_fraction", 0.1),
        "max_pairs_per_area": plan.get("max_pairs_per_area", 2000),
        "random_seed": plan.get("random_seed"),
        "pair_reviews": [
            {
                "pair_id": pair["pair_id"],
                "split": pair.get("split", split),
                "area_slug": pair["area_slug"],
                "high_sample_id": pair["high_sample_id"],
                "general_sample_id": pair["general_sample_id"],
                "high_review": empty_review(),
                "general_review": empty_review(),
                "pairwise_difference": [],
                "inferred_reviewer_concerns": [],
                "future_paper_checks": [],
                "rebuttal_revision_guidance": [],
                "completed": False,
            }
            for pair in plan.get(key, [])
        ],
    }


def write_bank_markdown(path: Path, bank: dict[str, Any]) -> None:
    lines = [
        "# Pair Review Bank",
        "",
        f"Split: `{bank['split']}`",
        "",
        "Anonymous template. Fill every pair review before generating or validating the taste profile.",
        "",
    ]
    for review in bank["pair_reviews"]:
        lines.extend(
            [
                f"## {review['pair_id']}",
                "",
                f"- Area: `{review['area_slug']}`",
                f"- High sample: `{review['high_sample_id']}`",
                f"- General sample: `{review['general_sample_id']}`",
                "- Completed: false",
                "",
                "### High Review",
                "",
                "Fill with anonymized single-paper review using `paper_review_rubric_for_contrastive.md`.",
                "",
                "### General Review",
                "",
                "Fill with anonymized single-paper review using `paper_review_rubric_for_contrastive.md`.",
                "",
                "### Pairwise Difference",
                "",
                "- not completed",
                "",
                "### Inferred Reviewer Concerns",
                "",
                "- not completed",
                "",
            ]
        )
    path.write_text("\n".join(lines), encoding="utf-8")


def write_outputs(output: Path, train_bank: dict[str, Any], validation_bank: dict[str, Any]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    (output / "pair_review_bank.json").write_text(json.dumps(train_bank, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "validation_pair_review_bank.json").write_text(
        json.dumps(validation_bank, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_bank_markdown(output / "pair_review_bank.md", train_bank)
    write_bank_markdown(output / "validation_pair_review_bank.md", validation_bank)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair-plan", required=True, help="Path to contrastive_pair_plan.json.")
    parser.add_argument("--output", required=True, help="Output directory.")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    plan = read_plan(Path(args.pair_plan))
    train_bank = build_bank(plan, "train")
    validation_bank = build_bank(plan, "validation")
    write_outputs(Path(args.output), train_bank, validation_bank)
    print(
        f"Wrote {len(train_bank['pair_reviews'])} training and "
        f"{len(validation_bank['pair_reviews'])} validation pair review templates to {Path(args.output).resolve()}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(__import__("sys").argv[1:]))
