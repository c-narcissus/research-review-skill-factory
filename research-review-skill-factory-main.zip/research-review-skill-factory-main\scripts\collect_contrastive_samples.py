#!/usr/bin/env python3
"""Collect anonymized contrastive sample manifests and a private source map."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


PAPER_EXTENSIONS = {".pdf", ".html", ".htm", ".txt", ".md", ".tex", ".docx"}
LEVEL_PREFIX = {"high_level": "H", "general_level": "G"}


def slugify(text: str, fallback: str = "unknown") -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    normalized = re.sub(r"-{2,}", "-", normalized)
    return normalized[:80].strip("-") or fallback


def is_url(value: str) -> bool:
    parsed = urllib.parse.urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def source_key(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()


def public_note(status: str) -> str:
    if status == "downloaded":
        return "direct public source downloaded; identifying details kept only in private source map"
    if status == "found":
        return "source found; identifying details kept only in private source map"
    if status == "failed":
        return "source could not be collected; see private source map for local troubleshooting"
    return "non-identifying sample record"


def iter_local_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path] if path.suffix.lower() in PAPER_EXTENSIONS else []
    if path.is_dir():
        return sorted(file for file in path.rglob("*") if file.is_file() and file.suffix.lower() in PAPER_EXTENSIONS)
    return []


def infer_area_slug(file: Path, source_root: Path | None, default_area_slug: str) -> str:
    if source_root and source_root.is_dir():
        try:
            relative = file.relative_to(source_root)
            if len(relative.parts) > 1:
                return slugify(relative.parts[0], default_area_slug)
        except ValueError:
            pass
    return slugify(default_area_slug, "unknown")


def download_url(url: str, download_dir: Path, level: str, max_bytes: int) -> tuple[str, str]:
    parsed = urllib.parse.urlparse(url)
    name = Path(parsed.path).name or slugify(parsed.netloc)
    target = download_dir / level / name
    target.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "contrastive-sample-collector/1.0"})
    total = 0
    with urllib.request.urlopen(req, timeout=45) as response, target.open("wb") as handle:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise RuntimeError(f"download exceeded {max_bytes} bytes")
            handle.write(chunk)
    return str(target), f"downloaded {total} bytes"


def make_records(
    level: str,
    source: str,
    download_dir: Path | None,
    download_public: bool,
    max_download_bytes: int,
    default_area_slug: str,
) -> list[dict[str, Any]]:
    path = Path(source)
    if path.exists():
        files = iter_local_files(path)
        if not files:
            return [
                {
                    "level": level,
                    "area_slug": slugify(default_area_slug, "unknown"),
                    "source_type": "local_folder" if path.is_dir() else "local_file",
                    "status": "skipped",
                    "title_or_name": path.name,
                    "source": source,
                    "local_path": str(path.resolve()),
                    "url": "",
                    "document_key": source_key(str(path.resolve())),
                    "private_notes": "no supported paper files found",
                }
            ]
        source_type = "local_folder" if path.is_dir() else "local_file"
        return [
            {
                "level": level,
                "area_slug": infer_area_slug(file, path if path.is_dir() else None, default_area_slug),
                "source_type": source_type,
                "status": "found",
                "title_or_name": file.name,
                "source": source,
                "local_path": str(file.resolve()),
                "url": "",
                "document_key": source_key(str(file.resolve())),
                "private_notes": "",
            }
            for file in files
        ]

    if is_url(source):
        status = "found"
        local_path = ""
        private_notes = "public URL recorded; download not requested"
        if download_public and download_dir is not None:
            try:
                local_path, private_notes = download_url(source, download_dir, level, max_download_bytes)
                status = "downloaded"
            except Exception as exc:  # noqa: BLE001 - retain failure privately.
                status = "failed"
                private_notes = str(exc)
        return [
            {
                "level": level,
                "area_slug": slugify(default_area_slug, "unknown"),
                "source_type": "url",
                "status": status,
                "title_or_name": Path(urllib.parse.urlparse(source).path).name or source,
                "source": source,
                "local_path": local_path,
                "url": source,
                "document_key": source_key(source),
                "private_notes": private_notes,
            }
        ]

    return [
        {
            "level": level,
            "area_slug": slugify(default_area_slug, "unknown"),
            "source_type": "named_source",
            "status": "found",
            "title_or_name": source,
            "source": source,
            "local_path": "",
            "url": "",
            "document_key": source_key(source),
            "private_notes": "named source; resolve manually or with public web search when used",
        }
    ]


def assign_anonymous_ids(records: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    counters: dict[tuple[str, str], int] = {}
    public_samples: list[dict[str, Any]] = []
    private_samples: dict[str, Any] = {}

    level_order = {"high_level": 0, "general_level": 1}
    for item in sorted(
        records,
        key=lambda row: (
            row["area_slug"],
            level_order.get(str(row["level"]), 99),
            row.get("local_path") or row.get("url") or row.get("source"),
        ),
    ):
        area_slug = slugify(str(item["area_slug"]), "unknown")
        level = str(item["level"])
        counters[(area_slug, level)] = counters.get((area_slug, level), 0) + 1
        prefix = LEVEL_PREFIX[level]
        sample_id = f"{area_slug}:{prefix}{counters[(area_slug, level)]:03d}"
        selection_status = "eligible" if item["status"] in {"found", "downloaded"} else "ineligible"
        public_samples.append(
            {
                "sample_id": sample_id,
                "area_slug": area_slug,
                "level": level,
                "source_type": item["source_type"],
                "status": item["status"],
                "selection_status": selection_status,
                "notes": public_note(item["status"]),
            }
        )
        private_samples[sample_id] = {
            "sample_id": sample_id,
            "area_slug": area_slug,
            "level": level,
            "source_type": item["source_type"],
            "status": item["status"],
            "source": item["source"],
            "title_or_name": item["title_or_name"],
            "local_path": item["local_path"],
            "url": item["url"],
            "document_key": item["document_key"],
            "private_notes": item["private_notes"],
        }
    return public_samples, private_samples


def count_by_area(samples: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
    counts: dict[str, dict[str, int]] = {}
    for sample in samples:
        area = sample["area_slug"]
        level = sample["level"]
        counts.setdefault(area, {"high_level": 0, "general_level": 0})
        counts[area][level] += 1
    return counts


def write_manifest(output: Path, records: list[dict[str, Any]], sources: dict[str, list[str]]) -> None:
    output.mkdir(parents=True, exist_ok=True)
    public_samples, private_samples = assign_anonymous_ids(records)
    generated_at = dt.datetime.now(dt.timezone.utc).isoformat()
    payload = {
        "generated_at_utc": generated_at,
        "privacy": "public anonymized manifest; original identifiers are only in private_source_map.json",
        "samples": public_samples,
        "counts": {
            "high_level": sum(1 for sample in public_samples if sample["level"] == "high_level"),
            "general_level": sum(1 for sample in public_samples if sample["level"] == "general_level"),
            "by_area": count_by_area(public_samples),
        },
    }
    (output / "sample_source_manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (output / "private_source_map.json").write_text(
        json.dumps(
            {
                "generated_at_utc": generated_at,
                "privacy": "private; do not package or copy into child skills",
                "sources": sources,
                "samples": private_samples,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    lines = ["# Sample Source Manifest", "", "Public anonymized manifest. Do not add source titles, authors, URLs, paths, or filenames.", ""]
    for area, levels in sorted(count_by_area(public_samples).items()):
        lines.extend([f"## Area `{area}`", "", f"- high_level: `{levels.get('high_level', 0)}`", f"- general_level: `{levels.get('general_level', 0)}`", ""])
        for sample in [item for item in public_samples if item["area_slug"] == area]:
            lines.append(f"- `{sample['sample_id']}` {sample['level']} {sample['status']} {sample['source_type']}")
        lines.append("")
    (output / "sample_source_manifest.md").write_text("\n".join(lines), encoding="utf-8")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--high-source", action="append", default=[], help="High-level sample source. Repeatable.")
    parser.add_argument("--general-source", action="append", default=[], help="General-level sample source. Repeatable.")
    parser.add_argument("--output", required=True, help="Output directory for sample_source_manifest files.")
    parser.add_argument("--area-slug", default="unknown", help="Default area slug when it cannot be inferred from subfolders.")
    parser.add_argument("--download-public", action="store_true", help="Download direct public URLs into the output directory.")
    parser.add_argument("--max-download-mb", type=int, default=80)
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if not args.high_source or not args.general_source:
        raise ValueError("Provide at least one --high-source and one --general-source.")
    output = Path(args.output)
    download_dir = output / "downloads" if args.download_public else None
    max_bytes = args.max_download_mb * 1024 * 1024
    records: list[dict[str, Any]] = []
    for source in args.high_source:
        records.extend(make_records("high_level", source, download_dir, args.download_public, max_bytes, args.area_slug))
    for source in args.general_source:
        records.extend(make_records("general_level", source, download_dir, args.download_public, max_bytes, args.area_slug))
    write_manifest(output, records, {"high_level": args.high_source, "general_level": args.general_source})
    print(f"Wrote {len(records)} anonymized sample records to {output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(__import__("sys").argv[1:]))
