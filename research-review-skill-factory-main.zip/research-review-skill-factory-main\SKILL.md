---
name: research-review-skill-factory
description: Build custom peer-review skills for one or more specific research areas, problem families, and method combinations using OpenReview evidence first, with a contrastive high-level-vs-general sample fallback when public OpenReview reviews are sparse. Use when Codex needs a compact meta-review skill factory that retrieves and synthesizes recent ICLR/OpenReview reviewer concerns, enforces per-area evidence sufficiency, learns reviewer taste from user-provided sample sources when needed, then generates a ClawHub-ready reviewer skill tailored to the area/problem rather than to one specific manuscript.
license: MIT-0
metadata:
  openclaw:
    emoji: "review-factory"
    requires:
      anyBins:
        - python3
        - python
---

# Research Review Skill Factory

Use this meta-skill to build a custom review skill for one or more research areas, problem families, or method combinations. It is broader than a manuscript-specific builder: the generated child skill should help review future papers in the selected area.

## Core Idea

Create field/problem-specific reviewer skills with an OpenReview-first evidence gate:

```text
research area + problem set -> area profile -> OpenReview queries
  -> per-area sufficiency check
  -> OpenReview bank OR contrastive reviewer taste profile
  -> custom area reviewer skill
```

Examples:

- `sparse-sensing-theory-reviewer-openreview`
- `causal-robustness-reviewer-openreview`
- `spectral-representation-theory-reviewer-openreview`
- `interactive-agent-benchmark-reviewer-openreview`

## Workflow

1. **Define the research area and problem set**
   - Ask for or infer each area scope: narrow field, parent fields, problem family, method families, theory objects, experiment settings, and target venues.
   - If the user gives multiple fields, split them into independent profiles. Do not merge evidence across fields.
   - Use `references/research_area_profile_schema.md`.
   - Preserve narrow terms before broad terms.

2. **Generate OpenReview query plan**
   - Create 8-20 queries covering the exact area phrase, subproblems, method families, theory or benchmark keywords, closest baseline families, and broader fallback fields.
   - Use the runtime current year and the two previous years by default: `[current_year, current_year - 1, current_year - 2]`.
   - Do not silently expand beyond three years when the current year is unavailable; record the limitation unless the user explicitly asks for more years.

3. **Retrieve public OpenReview evidence**
   - Use:

```bash
python scripts/fetch_openreview_field_evidence.py --field "<area query>" --output "<evidence-dir>/<area-slug>"
```

   - For multiple independent areas, pass multiple `--field` values or run once per area.
   - Collect reviewer concerns from accepted, rejected, withdrawn, and desk-rejected public submissions when available.
   - Use author responses only from accepted papers by default.

4. **Apply the per-area evidence gate**
   - Read `references/evidence_sufficiency_and_fallback.md`.
   - Each area must independently have at least 20 relevant OpenReview papers with public review notes in the default three-year window.
   - A public review note means an `Official_Review` or equivalent public reviewer note. Do not combine counts across areas.

5. **Synthesize the appropriate evidence artifact**
   - If the area passes the gate, synthesize an OpenReview review-response bank.
   - Cluster reviewer concerns by category.
   - For each pattern, record trigger terms, reviewer concern, accepted-paper response pattern, what future papers in this area must show, and representative evidence.
   - Keep direct quotes short; paraphrase patterns and cite forum URLs.
   - If the area fails the gate, read `references/contrastive_reviewer_taste_workflow.md` and use high-level vs general-level sample sources to build a contrastive reviewer taste profile.
   - Choose the contrastive module explicitly:
     - use the default high-throughput module in `references/contrastive_pair_review_workflow.md` when the user wants broad pair coverage, train/validation splitting, and up to 2000 pairs;
     - use the replaceable deep-read matched module in `references/deep_read_matched_contrastive_module.md` when the user asks to deeply read curated high-level papers, match each to a same-area or related general-level paper, then infer reviewer taste from one-to-one comparisons.
   - In contrastive mode, each sparse area requires at least 20 training pairs and a document-level held-out validation split that is both more than 20 pairs and at least 10% of the selected pair count.
   - Select up to 2000 total pairs per area: `min(actual_possible_pairs, 2000)`, preserving the validation holdout.
   - Blind-review each paper first without exposing the high/general source label. Reveal labels only after the single-paper reviews are complete, then compare high/general differences and infer reviewer concerns from repeated differences across pairs.
   - In deep-read matched mode, generate structured single-paper deep-reading reports first, then create same-area or related-subfield high/general pairs, compare each pair, and synthesize a detailed aggregate profile. Keep reports and pair analyses external.
   - Write detailed pair reviews, the training rationale report, and validation report as external build artifacts only.
   - Iterate on training data until train pair coverage is at least 95%, the latest 200-pair training batch adds no more than one meaningful new axis, and top-axis stability is at least 0.85 over consecutive batches.
   - Use final held-out validation once to pass/fail and optionally strengthen or weaken existing training-derived axes. Do not add validation-only concerns into the child skill; keep them in the external validation report.
   - Require held-out validation success rate >= 90% per area, where a validation pair succeeds if at least one of its inferred concerns is covered by the training-derived taste axes.
   - Keep generated child-skill contrastive references anonymized; do not include sample paper titles, authors, filenames, URLs, paths, publication identifiers, or preprint registry IDs.
   - Use `references/contrastive_sample_source_schema.md` when asking for or reading sample sources.

6. **Generate the child area reviewer skill**
   - Use `scripts/init_research_area_review_skill.py` with a filled area profile JSON.
   - Use `--evidence-mode openreview` for sufficient OpenReview evidence, `--evidence-mode contrastive` for sparse OpenReview evidence, or `--evidence-mode hybrid` when both evidence types should be used.
   - The generated child skill must include `SKILL.md`, `agents/openai.yaml`, `references/research_area_profile.md`, `references/review_output_contract.md`, `references/subtle_logic_flaws.md`, `LICENSE.txt`, and `_meta.json`.
   - Include `references/openreview_review_response_bank.md` for `openreview` and `hybrid` modes.
   - Include only anonymized `references/contrastive_taste_profile.md`, `references/paper_review_rubric_for_contrastive.md`, and `references/privacy_and_anonymization_rules.md` for `contrastive` and `hybrid` modes.
   - Always include `references/runtime_literature_context_module.md` so the generated skill can retrieve target-paper-specific recent and canonical literature at review time.
   - The generated child skill must require a full-text reading gate for the nearest related work and expected baselines: accessible PDFs/full papers must be opened or downloaded and read before they are used for novelty, baseline, or missing-comparison judgments. Metadata-only records may be reported only as weak context.
   - Never include `private_source_map.json`, pair review banks, rationale reports, validation reports, sample manifests, raw PDFs, or reading notes in a child skill.

7. **Validate and package**
   - Run `quick_validate.py` on the child skill.
   - Run syntax checks on scripts.
   - Package the child skill only after confirming there are no raw evidence caches, PDFs, manuscripts, pycache, or private data.

## Generated Child Skill Requirements

The child skill must instruct future reviewers to:

- classify a submitted paper inside the target research area;
- retrieve the local OpenReview bank, contrastive taste profile, or both before writing review comments;
- build a runtime literature context pack from the submitted paper's related work, problem, method lineage, baselines, datasets, and claims;
- retrieve top-conference, top-journal, official-proceedings, recent, and canonical related work when internet or local corpus access is available, then cite retrieved works or state retrieval limits;
- obtain and read accessible full text for the nearest related works and expected baselines before making strong novelty, baseline, or missing-comparison claims;
- separate full-text-read, partial-full-text, metadata-only, and inaccessible works in the runtime literature context;
- treat preprints as supplemental evidence unless no top-venue or canonical source exists;
- generate area-specific reviewer concerns and rebuttal/revision guidance;
- cite OpenReview precedent with year, status, title, forum URL, and note type;
- cite contrastive precedent through final taste profile axes, aggregate support, and stated limitations;
- audit novelty, soundness, baselines, reproducibility, A+B incrementality, and subtle logic flaws;
- output a standalone subtle logic flaw audit table from the bundled checklist, marking non-applicable checks explicitly rather than omitting the section;
- provide light, moderate, and major revision paths.

## Evidence Rules

- Never fabricate OpenReview titles, forum IDs, decisions, scores, or author responses.
- Treat OpenReview evidence as precedent, not as law.
- Do not include raw review dumps in the generated child skill.
- If OpenReview evidence is sparse, do not pretend the area is OpenReview-grounded. Trigger contrastive reviewer taste modeling.
- Download only public, directly accessible materials. Treat user-provided local folders as user-authorized inputs, but do not package raw papers into generated child skills.
- Do not package private source maps or identifying contrastive sample metadata.

## References

- `references/research_area_profile_schema.md`: area/problem profile schema.
- `references/openreview_area_evidence_workflow.md`: retrieval and synthesis protocol.
- `references/evidence_sufficiency_and_fallback.md`: 20-reviewed-paper per-area gate and sparse fallback rules.
- `references/contrastive_sample_source_schema.md`: high-level and general-level sample source schema.
- `references/contrastive_reviewer_taste_workflow.md`: sparse-field contrastive taste modeling protocol.
- `references/contrastive_pair_review_workflow.md`: 20-pair same-area review-and-contrast protocol.
- `references/deep_read_matched_contrastive_module.md`: replaceable strict module for deep-reading curated samples, matching high/general papers one-to-one, and summarizing reviewer taste.
- `references/runtime_literature_context_module.md`: replaceable runtime module for target-paper-specific literature retrieval, multi-hop problem lifting, knowledge graph/RAG context, and review-context mapping.
- `references/paper_review_rubric_for_contrastive.md`: single-paper review rubric for contrastive mode.
- `references/privacy_and_anonymization_rules.md`: privacy rules for contrastive artifacts.
- `references/generated_area_review_skill_contract.md`: generated child skill contract.
- `references/subtle_logic_flaws.md`: reusable hidden-weakness checklist.
