# Contrastive Pair Review Workflow

Use this workflow only after an area fails the OpenReview 20-reviewed-paper gate or the user explicitly requests contrastive reviewer taste modeling.

## Minimum Pair Count

- Each `area_slug` must have at least 20 training high/general pairs.
- The held-out validation split must be document-level disjoint, larger than 20 pairs, and at least 10% of the selected pair count.
- Select up to 2000 total pairs per area: `min(actual_possible_pairs, 2000)`, while reserving the validation split.
- A pair contains one `high_level` sample and one `general_level` sample from the same `area_slug`.
- Do not pair across areas.
- Do not repeat the same high/general pair.
- The same paper may appear in multiple different pairs.
- A validation sample must not appear in any training pair.
- If an area cannot form both the training minimum and held-out validation minimum, stop and request more samples or permission to collect public samples.

## Required Order

1. Select train and validation pairs with `scripts/select_contrastive_pairs.py`.
2. Initialize train and validation review banks with `scripts/init_pair_review_bank.py`.
3. Deep-read and blind-review only training PDFs before creating the candidate taste profile; single-paper reviews must not use high/general labels.
4. Reveal high/general labels only after blind single-paper reviews are complete, then compare pair differences and infer training-derived taste axes.
5. Iterate on the training set until train pair coverage is at least 95%, the latest 200-pair training batch adds no more than one meaningful new axis, and top-axis stability is at least 0.85 over consecutive batches.
6. Deep-read validation PDFs only after the training profile is frozen.
7. Use final validation once to pass/fail and optionally strengthen or weaken existing training-derived axes. Do not add validation-only concerns into the child skill; report them externally.
8. Require validation success rate >= 90% per area; a validation pair succeeds if at least one inferred concern is covered by training-derived taste axes.
9. Keep train review banks, rationale reports, validation reports, and reading notes outside the child skill.

## Pair Review Record

Each pair review must include:

- `pair_id`;
- `area_slug`;
- `high_sample_id`;
- `general_sample_id`;
- `high_review`;
- `general_review`;
- `pairwise_difference`;
- `inferred_reviewer_concerns`;
- `future_paper_checks`;
- `rebuttal_revision_guidance`;
- `completed: true`.

Do not include paper names, authors, filenames, URLs, paths, DOI strings, arXiv IDs, or identifying details in the review bank.

Single-paper review fields must record that they were produced before label reveal. Pair-level fields may use anonymous high/general IDs because the label reveal has already happened.
