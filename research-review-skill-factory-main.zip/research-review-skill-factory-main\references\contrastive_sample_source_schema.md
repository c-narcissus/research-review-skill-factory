# Contrastive Sample Source Schema

Use this schema when OpenReview public reviews are sparse or the user explicitly requests contrastive reviewer taste modeling.

## Source Types

The user may provide high-level and general-level examples through any mix of:

- local folders containing papers or notes;
- direct public PDF, HTML, arXiv, OpenReview, conference, journal, or project URLs;
- named venues, journals, workshops, tracks, special issues, or curated lists that the skill can search or download from public pages;
- existing manifests or text files listing sample metadata.

Do not bypass login, subscription, robots restrictions, or paywalls. Download only directly accessible public materials. Treat user-provided local folders as user-authorized inputs, but do not package raw papers into generated child skills.

## JSON Shape

```json
{
  "contrastive_sample_sources": {
    "high_level": [
      {
        "source_type": "local_folder | url | venue | journal | manifest",
        "location": "",
        "selection_rule": "",
        "expected_count": null,
        "notes": ""
      }
    ],
    "general_level": [
      {
        "source_type": "local_folder | url | venue | journal | manifest",
        "location": "",
        "selection_rule": "",
        "expected_count": null,
        "notes": ""
      }
    ]
  }
}
```

## Minimum Manifest Fields

For each collected sample, record:

- `sample_id`: anonymous ID such as `area_slug:H001` or `area_slug:G001`;
- `area_slug`;
- `level`: `high_level` or `general_level`;
- `source_type`;
- `status`: `found`, `downloaded`, `skipped`, or `failed`;
- `selection_status`;
- `notes` only when non-identifying.

If the user asks to compare folders only, do not supplement samples unless asked.

Original filenames, paths, URLs, titles, authors, and source identifiers belong only in `private_source_map.json`, not in the public manifest or generated child skill.
