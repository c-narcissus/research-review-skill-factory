# Deep-Read Matched Contrastive Module

Use this replaceable module when the user wants a stricter contrastive fallback than high-volume pair sampling, especially when the available high-level set is small enough to read deeply.

This module is a protocol boundary. Future versions may replace the matching strategy, deep-reading prompt, pair comparator, or profile synthesizer without changing the OpenReview evidence gate or child-skill packaging rules.

## When To Use

Use this module instead of the high-throughput contrastive workflow when:

- the user explicitly asks for deep reading before comparison;
- the high-level sample set is small or curated;
- reviewer-taste quality matters more than pair volume;
- the user wants each high-level sample paired with a same-area or closely related general-level sample;
- the user wants detailed reports as external artifacts but only aggregate rules inside the child skill.

Do not use this module when the task is only to create a fast broad taste estimate from many pairs. In that case, use `contrastive_pair_review_workflow.md`.

## Replaceable Components

Each implementation of this module must expose these conceptual components:

- `domain_adapter`: area-specific vocabulary, subfields, benchmark families, metrics, and known failure modes.
- `deep_reader`: single-paper reading prompt or tool. It must produce structured, anonymized reports.
- `subfield_matcher`: selects same-area or closely related high/general pairs.
- `pair_comparator`: compares one high-level and one general-level report and explains why the high-level sample is stronger and where the general-level sample falls short.
- `taste_synthesizer`: aggregates pair records into reviewer-taste axes.
- `privacy_filter`: removes titles, authors, filenames, URLs, local paths, identifiers, and raw source text from child-skill artifacts.

These components may be implemented by scripts, prompts, or manual review, but their outputs must obey the artifact contract below.

## Required Inputs

- An anonymized sample manifest.
- A private source map kept outside any child skill or published package.
- High-level sample sources.
- General-level sample sources.
- Area profile with subfields, methods, settings, baselines, and metrics.
- Target pair count. Default: one pair per selected high-level sample.
- Pairing policy. Default: one-to-one, no paper reuse.

## Required External Artifacts

Keep these outside the generated child skill:

- `deep_read_reports/`: one anonymized structured report per selected paper.
- `matched_pair_plan.md/json`: one-to-one or configured pair plan.
- `pair_analyses/`: one report per matched pair.
- `pairwise_analyses.json`: structured pair analysis records.
- `contrastive_inference_rationale_report.md/json`: aggregate rationale for taste axes.
- optional `reading_coverage_summary.md`.
- `private_source_map.json`, local-only and never packaged.

The external reports may use anonymous IDs if needed. They must not include original paper identity.

## Child-Safe Artifacts

Only these may enter a generated child skill:

- final `contrastive_taste_profile.md`;
- `paper_review_rubric_for_contrastive.md`;
- `privacy_and_anonymization_rules.md`;
- aggregate counts and limitations in `research_area_profile.md`.

The child-safe taste profile must not contain sample IDs, pair IDs, titles, authors, filenames, URLs, local paths, DOI strings, preprint IDs, raw paper text, private-map references, or detailed pair reports.

## Procedure

1. **Anonymize sources**
   - Build public sample records and a private map.
   - Use only anonymous IDs in all later artifacts.

2. **Choose selected papers**
   - Select all high-level papers when the set is intentionally curated and manageable.
   - Select the same number of general-level papers by same-area or related-subfield matching.
   - Default to no reuse. If reuse is allowed, record why.

3. **Deep-read individual papers**
   - Generate a structured report for each selected paper before pairwise comparison.
   - Use the common contrastive review rubric plus area-specific reader questions from the domain adapter.
   - The single-paper report should not use the source label as evidence of quality.
   - Record reading coverage, missing sections, and uncertainty.

4. **Match high/general pairs**
   - Prefer one high-level paper to one same-subfield or closely related general-level paper.
   - Match on problem family, method family, setting, benchmark family, metric, theory object, or deployment constraint.
   - Default to one-to-one no-reuse matching.

5. **Compare each pair**
   - Explain why the high-level paper is stronger in area-specific review terms.
   - Explain why the general-level paper falls short.
   - Infer candidate reviewer concerns only from the deep-reading reports and the pair comparison.
   - Record counterexamples or cases where the general-level sample is strong on a particular axis.

6. **Synthesize reviewer taste**
   - Aggregate recurring concerns across pairs.
   - Separate universal axes from subfield-specific axes.
   - For each axis, include:
     - reviewer taste;
     - stronger-paper pattern;
     - weaker-paper gap;
     - review questions;
     - rebuttal or revision advice;
     - applicable subfields and exceptions;
     - aggregate support.

7. **Apply privacy filter**
   - Generate a child-safe profile without sample IDs or paper identities.
   - Keep detailed reports external.
   - Package the child skill with a whitelist, never by copying the whole build directory.

## Module Plan Schema

```json
{
  "module": "deep_read_matched_contrastive",
  "module_version": "1.0",
  "area_slug": "",
  "target_pair_count": 0,
  "pairing_policy": "one_to_one_no_reuse",
  "selected_high_level_count": 0,
  "selected_general_level_count": 0,
  "external_artifacts": [],
  "child_safe_artifacts": [],
  "replaceable_components": {
    "domain_adapter": "",
    "deep_reader": "",
    "subfield_matcher": "",
    "pair_comparator": "",
    "taste_synthesizer": "",
    "privacy_filter": ""
  },
  "privacy_forbidden_in_child": [],
  "status": "planned"
}
```

Use `scripts/init_deep_read_matched_contrastive_module.py` to create a module plan and empty artifact folders before running an implementation.
