# Publishing To ClawHub

Skill slug: `research-review-skill-factory`
Version: `1.1.0`
License: `MIT-0`

## Package Contents

- `SKILL.md`
- `README.md`
- `agents/openai.yaml`
- `references/`
- `scripts/fetch_openreview_field_evidence.py`
- `scripts/init_research_area_review_skill.py`
- `scripts/collect_contrastive_samples.py`
- `scripts/select_contrastive_pairs.py`
- `scripts/init_pair_review_bank.py`
- `scripts/build_contrastive_taste_profile.py`
- `LICENSE.txt`
- `_meta.json`
- `PUBLISH_PAGE_INFO_CN.md`

Do not include generated child skills, raw OpenReview caches, PDFs, manuscripts, pycache, private review files, or `private_source_map.json` in the upload package.

## Recommended Publish Command

```bash
clawhub skill publish ./research-review-skill-factory --version 1.1.0
```
