#!/usr/bin/env python3
"""Deep-read selected anonymous contrastive pairs and fill pair review banks."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


try:  # Prefer PyMuPDF when available because it is fast and handles many PDFs.
    import fitz  # type: ignore
except Exception:  # pragma: no cover - optional dependency.
    fitz = None

try:
    from pypdf import PdfReader
except Exception:  # pragma: no cover - optional dependency.
    PdfReader = None  # type: ignore


SETTING_TERMS = {
    "distribution shift or heterogeneity": ["distribution shift", "heterogeneous", "heterogeneity", "domain shift", "subpopulation", "covariate shift"],
    "personalization or adaptation": ["personalized", "personalization", "adaptation", "adaptive", "specialized", "local adaptation"],
    "privacy/security/robustness": ["privacy", "private", "differential privacy", "secure", "attack", "backdoor", "poisoning", "robust", "inference"],
    "efficiency or scalability": ["communication", "compression", "bandwidth", "rounds", "asynchronous", "edge", "latency", "memory", "throughput"],
    "large-model or representation learning": ["large language model", "transformer", "representation", "fine-tuning", "adapter", "prompt"],
    "graph/multimodal/domain-specific data": ["graph", "multimodal", "time series", "trajectory", "medical", "recommendation"],
    "optimization/theory": ["convergence", "theorem", "lemma", "proof", "rate", "optimal", "complexity"],
    "fairness/causality/unlearning": ["unlearning", "fairness", "causal", "calibration"],
}
BASELINES = ["baseline", "comparison", "state-of-the-art", "sota", "prior work", "competing method", "standard method", "ablated", "oracle", "upper bound", "lower bound"]
DATASETS = ["mnist", "cifar", "imagenet", "celeba", "reddit", "stackoverflow", "ag news", "sst", "glue", "alpaca", "medical", "mimic", "flickr", "yelp", "amazon", "movielens", "synthetic"]
CLAIM_WORDS = ["state-of-the-art", "outperform", "superior", "optimal", "near-optimal", "provable", "robust", "privacy-preserving", "efficient", "scalable", "first", "novel"]
SECTION_TERMS = {
    "abstract": ["abstract"],
    "introduction": ["introduction", "1 introduction"],
    "method": ["method", "methodology", "algorithm", "approach"],
    "experiment": ["experiment", "evaluation", "empirical"],
    "appendix": ["appendix", "supplementary"],
    "limitation": ["limitation", "limitations", "future work"],
}


def read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} must contain a JSON object.")
    return data


def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def extract_pdf(path: Path, max_pages: int = 80) -> tuple[str, dict[str, Any]]:
    page_count = 0
    chunks: list[str] = []
    if fitz is not None:
        try:
            doc = fitz.open(str(path))
            page_count = len(doc)
            for page in doc[: min(max_pages, len(doc))]:
                chunks.append(page.get_text("text"))
        except Exception:
            chunks = []
    if not chunks and PdfReader is not None:
        reader = PdfReader(str(path))
        page_count = len(reader.pages)
        for page in reader.pages[: min(max_pages, page_count)]:
            chunks.append(page.extract_text() or "")
    text = clean_text("\n".join(chunks))
    lower = text.lower()
    coverage = {
        "page_count": page_count,
        "pages_read": min(max_pages, page_count) if page_count else 0,
        "extracted_characters": len(text),
        "section_coverage": {
            name: any(term in lower for term in terms)
            for name, terms in SECTION_TERMS.items()
        },
    }
    return text[:200_000], coverage


def count_any(lower: str, terms: list[str]) -> int:
    return sum(lower.count(term) for term in terms)


def features(sample_id: str, private_samples: dict[str, Any]) -> dict[str, Any]:
    private = private_samples[sample_id]
    path = Path(private["local_path"])
    text, coverage = extract_pdf(path)
    lower = text.lower()
    settings = [name for name, terms in SETTING_TERMS.items() if any(term in lower for term in terms)]
    baseline_hits = sorted({baseline for baseline in BASELINES if baseline in lower})
    dataset_hits = sorted({dataset for dataset in DATASETS if dataset in lower})
    return {
        "sample_id": sample_id,
        "reading_coverage": coverage,
        "settings": settings[:5],
        "baseline_count": len(baseline_hits),
        "dataset_count": len(dataset_hits),
        "theory_score": count_any(lower, ["theorem", "lemma", "proof", "convergence", "assumption", "complexity", "rate"]),
        "experiment_score": count_any(lower, ["experiment", "evaluation", "baseline", "dataset", "ablation", "comparison"]),
        "ablation_score": count_any(lower, ["ablation", "sensitivity", "hyperparameter", "component", "variant"]),
        "reproducibility_score": count_any(lower, ["appendix", "implementation", "code", "hyperparameter", "configuration", "reproduce"]),
        "limitations_score": count_any(lower, ["limitation", "future work", "fail", "only", "assume", "assumption"]),
        "claim_count": count_any(lower, CLAIM_WORDS),
        "domain_specificity_score": count_any(lower, ["task", "dataset", "model", "method", "training", "evaluation", "benchmark", "metric", "experiment", "theory", "application"]),
        "baseline_examples": baseline_hits[:6],
        "dataset_examples": dataset_hits[:6],
    }


def level_word(score: int, low: int, high: int) -> str:
    if score >= high:
        return "strong"
    if score >= low:
        return "moderate"
    return "limited"


def setting_summary(item: dict[str, Any]) -> str:
    return ", ".join(item["settings"][:3]) if item["settings"] else "general research setting"


def weakness_list(item: dict[str, Any]) -> list[str]:
    weaknesses: list[str] = []
    if item["baseline_count"] < 3:
        weaknesses.append("baseline coverage may be too narrow for reviewer confidence")
    if item["dataset_count"] < 2:
        weaknesses.append("dataset or setting diversity may not support broad claims")
    if item["ablation_score"] < 2:
        weaknesses.append("mechanism attribution may be weak without ablations or sensitivity analysis")
    if item["reproducibility_score"] < 3:
        weaknesses.append("implementation and hyperparameter detail may be insufficient")
    if item["theory_score"] < 5 and item["claim_count"] >= 5:
        weaknesses.append("strong claims may lack matching theoretical or assumption analysis")
    return weaknesses or ["main residual risk is whether the claimed setting matches realistic evaluation constraints"]


def blind_review_from_features(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "review_stage": "blind_single_paper_review_before_label_reveal",
        "label_visibility": "high/general sample level hidden during this single-paper review",
        "contribution_summary": f"Anonymous sample addresses {setting_summary(item)} with method, theory, evaluation, robustness, adaptation, or efficiency claims depending on its setting.",
        "problem_importance": f"{level_word(item['domain_specificity_score'], 15, 40)} domain specificity across task, data, model, evaluation, theory, or deployment constraints.",
        "novelty_and_incrementality": f"{level_word(item['claim_count'], 4, 10)} novelty signaling; check whether novelty is more than recombining known modules.",
        "technical_soundness": f"{level_word(item['theory_score'], 5, 18)} formal/algorithmic support based on theorem, assumption, proof, convergence, or complexity markers.",
        "claim_evidence_alignment": f"{level_word(item['experiment_score'], 8, 20)} experimental support and {level_word(item['theory_score'], 5, 18)} theory support.",
        "experiments_baselines_ablations": f"{level_word(item['baseline_count'], 2, 4)} baseline diversity, {level_word(item['dataset_count'], 2, 4)} dataset diversity, and {level_word(item['ablation_score'], 1, 4)} ablation/sensitivity evidence.",
        "reproducibility": f"{level_word(item['reproducibility_score'], 2, 6)} implementation and hyperparameter detail markers.",
        "limitations_and_overclaim": f"{level_word(item['limitations_score'], 2, 6)} limitation/scope-control markers; check assumptions and deployment boundaries.",
        "writing_clarity": "section coverage recorded in reading_coverage; review should inspect missing sections before relying on the sample.",
        "decision_impact_weaknesses": weakness_list(item),
        "reading_coverage": item["reading_coverage"],
    }


def concern(name: str, high_signal: str, general_gap: str, why: str, counter: str = "not reported") -> dict[str, str]:
    return {
        "concern": name,
        "high_level_signal": high_signal,
        "general_level_gap": general_gap,
        "why": why,
        "counterexample": counter,
    }


def pair_concerns(high: dict[str, Any], general: dict[str, Any]) -> tuple[list[str], list[dict[str, str]]]:
    differences: list[str] = []
    concerns: list[dict[str, str]] = []
    if high["baseline_count"] >= general["baseline_count"] or general["baseline_count"] < 3:
        differences.append("baseline and benchmark coverage differs across the pair")
        concerns.append(concern(
            "baseline fairness and benchmark coverage",
            f"high sample shows {level_word(high['baseline_count'], 2, 4)} baseline coverage and {level_word(high['dataset_count'], 2, 4)} dataset coverage",
            f"general sample shows {level_word(general['baseline_count'], 2, 4)} baseline coverage and {level_word(general['dataset_count'], 2, 4)} dataset coverage",
            "Reviewers need evidence that gains hold across standard comparators, settings, and datasets rather than one favorable setup",
        ))
    if high["ablation_score"] >= general["ablation_score"] or general["ablation_score"] < 2:
        differences.append("mechanism attribution and ablation depth differs across the pair")
        concerns.append(concern(
            "mechanism evidence and ablation completeness",
            f"high sample has {level_word(high['ablation_score'], 1, 4)} ablation/sensitivity markers",
            f"general sample has {level_word(general['ablation_score'], 1, 4)} ablation/sensitivity markers",
            "Research methods often combine multiple components; reviewers need ablations to identify the source of gains",
        ))
    if high["theory_score"] >= general["theory_score"] or general["theory_score"] < 5:
        differences.append("formal assumption or convergence support differs across the pair")
        concerns.append(concern(
            "theory-to-method alignment and assumption clarity",
            f"high sample has {level_word(high['theory_score'], 5, 18)} theory/assumption markers",
            f"general sample has {level_word(general['theory_score'], 5, 18)} theory/assumption markers",
            "Reviewers scrutinize whether theory, robustness, privacy, or efficiency claims hold under assumptions matching the method and experiments",
        ))
    if high["domain_specificity_score"] >= general["domain_specificity_score"] or general["domain_specificity_score"] < 20:
        differences.append("domain-specific setting realism differs across the pair")
        concerns.append(concern(
            "domain setting realism and evaluation-condition match",
            f"high sample shows {level_word(high['domain_specificity_score'], 15, 40)} domain-specific constraint coverage for {setting_summary(high)}",
            f"general sample shows {level_word(general['domain_specificity_score'], 15, 40)} domain-specific constraint coverage for {setting_summary(general)}",
            "A method can look strong under simplified conditions but fail when data, models, assumptions, resources, or deployment constraints change",
        ))
    if high["reproducibility_score"] >= general["reproducibility_score"] or general["reproducibility_score"] < 3:
        differences.append("implementation and reproducibility detail differs across the pair")
        concerns.append(concern(
            "reproducibility and hyperparameter transparency",
            f"high sample has {level_word(high['reproducibility_score'], 2, 6)} implementation-detail markers",
            f"general sample has {level_word(general['reproducibility_score'], 2, 6)} implementation-detail markers",
            "Empirical results are sensitive to data splits, model choices, training budgets, hyperparameters, implementation details, and evaluation protocols",
        ))
    if high["claim_count"] <= general["claim_count"] or general["limitations_score"] < 2:
        differences.append("claim scope and limitation discipline differs across the pair")
        concerns.append(concern(
            "scope control and overclaim discipline",
            f"high sample shows {level_word(high['limitations_score'], 2, 6)} scope/assumption markers relative to its claims",
            f"general sample shows {level_word(general['limitations_score'], 2, 6)} scope/assumption markers relative to its claims",
            "Reviewers penalize broad claims when assumptions, failure modes, client coverage, or deployment limits are underspecified",
        ))
    return differences, concerns


def build_review_bank(plan: dict[str, Any], private_map: dict[str, Any], split: str) -> tuple[dict[str, Any], dict[str, Any]]:
    key = "training_pairs" if split == "train" else "validation_pairs"
    private_samples = private_map["samples"]
    cache: dict[str, dict[str, Any]] = {}

    def get_features(sample_id: str) -> dict[str, Any]:
        if sample_id not in cache:
            cache[sample_id] = features(sample_id, private_samples)
        return cache[sample_id]

    pair_reviews = []
    for pair in plan.get(key, []):
        high = get_features(pair["high_sample_id"])
        general = get_features(pair["general_sample_id"])
        differences, concerns = pair_concerns(high, general)
        pair_reviews.append(
            {
                "pair_id": pair["pair_id"],
                "split": split,
                "area_slug": pair["area_slug"],
                "protocol": "blind_single_paper_reviews_then_label_reveal_pairwise_contrast",
                "label_reveal_stage": "high/general labels are used only after blind single-paper reviews are complete",
                "high_sample_id": pair["high_sample_id"],
                "general_sample_id": pair["general_sample_id"],
                "high_review": blind_review_from_features(high),
                "general_review": blind_review_from_features(general),
                "pairwise_difference": differences,
                "inferred_reviewer_concerns": concerns,
                "future_paper_checks": [
                    "Does the paper evaluate realistic settings matching its claim?",
                    "Are baselines tuned fairly under the same data, model, compute, and evaluation budget?",
                    "Do ablations isolate the method components responsible for the reported gains?",
                    "Are theory, robustness, privacy, or efficiency claims tied to explicit assumptions and failure modes?",
                ],
                "rebuttal_revision_guidance": [
                    "Use text-only clarification only for already-present assumptions or implementation details.",
                    "Add experiments when baseline fairness, heterogeneity coverage, or ablations are missing.",
                    "Scope down claims when theory or experiments do not cover the full claimed setting.",
                ],
                "completed": True,
            }
        )
    notes = {
        "split": split,
        "privacy": "anonymous reading notes; source identities remain only in private_source_map.json",
        "protocol": "blind_single_paper_reviews_before_label_reveal",
        "samples_read": list(cache.values()),
    }
    bank = {
        "privacy": "anonymous review bank generated from selected local PDFs; no paper identities retained",
        "protocol": "blind_single_paper_reviews_then_label_reveal_pairwise_contrast",
        "split": split,
        "random_seed": plan.get("random_seed"),
        "pair_reviews": pair_reviews,
    }
    return bank, notes


def write_bank_markdown(path: Path, bank: dict[str, Any]) -> None:
    lines = [
        "# Pair Review Bank",
        "",
        f"Split: `{bank['split']}`",
        "",
        "Anonymous completed pair reviews. Source identities are intentionally omitted.",
        "",
    ]
    for review in bank["pair_reviews"]:
        lines.extend(
            [
                f"## {review['pair_id']}",
                "",
                f"- Area: `{review['area_slug']}`",
                f"- High sample: `{review['high_sample_id']}`",
                f"- General sample: `{review['general_sample_id']}`",
                "- Completed: true",
                "",
                "### Pairwise Difference",
            ]
        )
        lines.extend(f"- {item}" for item in review["pairwise_difference"])
        lines.extend(["", "### Inferred Reviewer Concerns"])
        lines.extend(f"- {item['concern']}: {item['why']}" for item in review["inferred_reviewer_concerns"])
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pair-plan", required=True)
    parser.add_argument("--private-source-map", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--split", choices=["train", "validation", "all"], default="all")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    plan = read_json(Path(args.pair_plan))
    private_map = read_json(Path(args.private_source_map))
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    splits = ["train", "validation"] if args.split == "all" else [args.split]
    for split in splits:
        bank, notes = build_review_bank(plan, private_map, split)
        prefix = "" if split == "train" else "validation_"
        (output / f"{prefix}pair_review_bank.json").write_text(json.dumps(bank, ensure_ascii=False, indent=2), encoding="utf-8")
        (output / f"{prefix}paper_reading_notes.json").write_text(json.dumps(notes, ensure_ascii=False, indent=2), encoding="utf-8")
        write_bank_markdown(output / f"{prefix}pair_review_bank.md", bank)
        print(f"Wrote {len(bank['pair_reviews'])} {split} pair reviews")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(__import__("sys").argv[1:]))
